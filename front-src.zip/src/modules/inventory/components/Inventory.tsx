import React, { useState, useEffect, useRef } from 'react'
import { toast } from 'sonner'
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  AlertTriangle,
  History,
  ArrowRight,
  FilePlus,
  ChevronDown,
  ChevronUp,
  Check,
  Lock,
  Info,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  XCircle,
  X,
  Building2,
  Receipt,
  Calendar,
  CreditCard,
  Percent,
  Tag,
  DollarSign,
  Package,
  Layers,
  HelpCircle,
  Clock,
  Pill,
  ShieldAlert,
  ShieldCheck,
  ScanLine
} from 'lucide-react'
import { useInventoryStore } from '../store'
import { useAuthStore } from '../../auth/store'
import { Medicine, Vendor, InventoryBatch, Purchase } from '../../../types'
import { DataTable, ColumnDef } from '../../../components/common/DataTable'
import { formatDateTime } from '../../../lib/formatDate'
import ScanPurchaseInvoice from './ScanPurchaseInvoice'
import {
  getAvailableUnitsForMedicine,
  getLiveConversionSummary,
  formatStockBreakdown,
  convertToBaseQuantity,
  ALL_UNIT_OPTIONS
} from '../../../lib/unitConversion'

// Toast Component
function Toast({
  message,
  type,
  onClose
}: {
  message: string
  type: 'success' | 'error' | 'info'
  onClose: () => void
}) {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000)
    return () => clearTimeout(timer)
  }, [onClose])

  const bgColors = {
    success: 'bg-cyan-950 text-cyan-100 border-cyan-800/60',
    error: 'bg-red-950 text-red-100 border-red-800/60',
    info: 'bg-slate-900 text-white border-slate-700'
  }

  const icons = {
    success: <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />,
    error: <XCircle className="w-4 h-4 text-red-400 shrink-0" />,
    info: <Info className="w-4 h-4 text-cyan-400 shrink-0" />
  }

  return (
    <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-4 py-3 rounded-xl border shadow-xl backdrop-blur-md animate-fade-in transition-all text-sm font-medium ${bgColors[type]}`}>
      {icons[type]}
      <span>{message}</span>
      <button onClick={onClose} className="ml-2 hover:opacity-70 text-slate-400 hover:text-white cursor-pointer">
        <X className="w-4 h-4" />
      </button>
    </div>
  )
}

// Vendor Searchable Typeahead Combobox
function VendorTypeahead({
  vendors,
  value,
  onChange,
  placeholder = "Search vendor by name, phone, gstin...",
  error
}: {
  vendors: Vendor[]
  value: string
  onChange: (vendorId: string) => void
  placeholder?: string
  error?: string
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [highlightedIndex, setHighlightedIndex] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)

  const selectedVendor = vendors.find((v) => v.id === value)

  useEffect(() => {
    if (selectedVendor && !isOpen) {
      setQuery(selectedVendor.name)
    } else if (!value && !isOpen) {
      setQuery('')
    }
  }, [value, selectedVendor, isOpen])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false)
        if (selectedVendor) setQuery(selectedVendor.name)
        else setQuery('')
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [selectedVendor])

  const filtered = vendors.filter(
    (v) =>
      v.name.toLowerCase().includes(query.toLowerCase()) ||
      (v.phone && v.phone.includes(query)) ||
      (v.gstin && v.gstin.toLowerCase().includes(query.toLowerCase()))
  )

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen) {
      if (e.key === 'ArrowDown' || e.key === 'Enter') {
        setIsOpen(true)
        return
      }
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHighlightedIndex((prev) => (prev < filtered.length - 1 ? prev + 1 : prev))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlightedIndex((prev) => (prev > 0 ? prev - 1 : 0))
    } else if (e.key === 'Enter') {
      e.preventDefault()
      if (filtered[highlightedIndex]) {
        onChange(filtered[highlightedIndex].id)
        setQuery(filtered[highlightedIndex].name)
        setIsOpen(false)
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false)
    }
  }

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="relative">
        <Building2 className="absolute left-3 top-2.5 h-4 w-4 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={query}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value)
            setIsOpen(true)
            setHighlightedIndex(0)
            if (value && e.target.value !== selectedVendor?.name) {
              onChange('')
            }
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          aria-label="Vendor search"
          aria-expanded={isOpen}
          className={`w-full pl-9 pr-8 py-2 text-sm rounded-lg border transition-all ${error
            ? 'border-red-300 bg-red-50/30 focus:ring-red-500'
            : value
              ? 'border-cyan-500 bg-cyan-50/20 font-semibold text-slate-900 focus:ring-cyan-500'
              : 'border-slate-200 focus:ring-cyan-500'
            } focus:outline-none focus:ring-2`}
        />
        <ChevronDown
          onClick={() => setIsOpen(!isOpen)}
          className="absolute right-3 top-2.5 h-4 w-4 text-slate-400 cursor-pointer hover:text-slate-600 transition-colors"
        />
      </div>

      {error && <p className="text-[11px] text-red-500 mt-1 font-medium">{error}</p>}

      {isOpen && (
        <ul className="absolute z-50 mt-1 w-full max-h-60 overflow-y-auto rounded-xl bg-white border border-slate-200 shadow-xl py-1 text-sm">
          {filtered.length === 0 ? (
            <li className="px-4 py-3 text-slate-400 text-xs text-center">No vendors found matching "{query}"</li>
          ) : (
            filtered.map((v, idx) => (
              <li
                key={v.id}
                onMouseEnter={() => setHighlightedIndex(idx)}
                onClick={() => {
                  onChange(v.id)
                  setQuery(v.name)
                  setIsOpen(false)
                }}
                className={`px-4 py-2.5 cursor-pointer flex justify-between items-center transition-colors ${idx === highlightedIndex ? 'bg-cyan-50 text-cyan-900 font-semibold' : 'text-slate-700 hover:bg-slate-50'
                  }`}
              >
                <div>
                  <div className="text-sm font-medium text-slate-900">{v.name}</div>
                  <div className="text-[11px] text-slate-400 font-mono flex gap-2">
                    {v.phone && <span>Ph: {v.phone}</span>}
                    {v.gstin && <span>GSTIN: {v.gstin}</span>}
                  </div>
                </div>
                {v.id === value && <Check className="w-4 h-4 text-cyan-600 shrink-0" />}
              </li>
            ))
          )}
        </ul>
      )}
    </div>
  )
}

// Medicine Searchable Typeahead Combobox
function MedicineTypeahead({
  medicines,
  value,
  onChange,
  placeholder = "Type medicine name, pack, generic...",
  inputRef,
  error
}: {
  medicines: Medicine[]
  value: string
  onChange: (medicine: Medicine | null) => void
  placeholder?: string
  inputRef?: React.RefObject<HTMLInputElement | null>
  error?: string
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [highlightedIndex, setHighlightedIndex] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)

  const selectedMed = medicines.find((m) => m.id === value)

  const formatMedLabel = (m?: Medicine | null) => {
    if (!m) return ''
    const parts = [m.name]
    if (m.strength) parts.push(m.strength)
    if (m.pack) parts.push(`[${m.pack}]`)
    return parts.join(' ')
  }

  useEffect(() => {
    if (selectedMed && !isOpen) {
      setQuery(formatMedLabel(selectedMed))
    } else if (!value && !isOpen) {
      setQuery('')
    }
  }, [value, selectedMed, isOpen])

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false)
        if (selectedMed) {
          setQuery(formatMedLabel(selectedMed))
        } else {
          setQuery('')
        }
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [selectedMed])

  const filtered = medicines.filter(
    (m) =>
      m.name.toLowerCase().includes(query.toLowerCase()) ||
      (m.strength || '').toLowerCase().includes(query.toLowerCase()) ||
      (m.generic_name || '').toLowerCase().includes(query.toLowerCase()) ||
      (m.manufacturer || '').toLowerCase().includes(query.toLowerCase()) ||
      (m.pack || '').toLowerCase().includes(query.toLowerCase()) ||
      (m.hsn_code || '').toLowerCase().includes(query.toLowerCase()) ||
      (m.rack_no || '').toLowerCase().includes(query.toLowerCase())
  )

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen && (e.key === 'ArrowDown' || e.key === 'Enter')) {
      setIsOpen(true)
      return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHighlightedIndex((prev) => (prev < filtered.length - 1 ? prev + 1 : prev))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlightedIndex((prev) => (prev > 0 ? prev - 1 : 0))
    } else if (e.key === 'Enter') {
      if (isOpen && filtered[highlightedIndex]) {
        e.preventDefault()
        const med = filtered[highlightedIndex]
        onChange(med)
        setQuery(formatMedLabel(med))
        setIsOpen(false)
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false)
    }
  }

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="relative">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400 pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value)
            setIsOpen(true)
            setHighlightedIndex(0)
            if (value && e.target.value !== selectedMed?.name) {
              onChange(null)
            }
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          aria-label="Medicine search"
          aria-expanded={isOpen}
          className={`w-full pl-9 pr-8 py-2 text-sm rounded-lg border transition-all ${error
            ? 'border-red-300 bg-red-50/30 focus:ring-red-500'
            : value
              ? 'border-cyan-500 bg-cyan-50/20 font-semibold text-slate-900 focus:ring-cyan-500'
              : 'border-slate-200 focus:ring-cyan-500'
            } focus:outline-none focus:ring-2`}
        />
        <ChevronDown
          onClick={() => setIsOpen(!isOpen)}
          className="absolute right-3 top-2.5 h-4 w-4 text-slate-400 cursor-pointer hover:text-slate-600 transition-colors"
        />
      </div>

      {error && <p className="text-[11px] text-red-500 mt-1 font-medium">{error}</p>}

      {isOpen && (
        <ul className="absolute z-50 mt-1 w-full max-h-72 overflow-y-auto rounded-xl bg-white border border-slate-200 shadow-2xl py-1 text-sm">
          {filtered.length === 0 ? (
            <li className="px-4 py-3 text-slate-400 text-xs text-center">No medicines found matching "{query}"</li>
          ) : (
            filtered.map((m, idx) => (
              <li
                key={m.id}
                onMouseEnter={() => setHighlightedIndex(idx)}
                onClick={() => {
                  onChange(m)
                  setQuery(formatMedLabel(m))
                  setIsOpen(false)
                }}
                className={`px-4 py-2.5 cursor-pointer border-b border-slate-100 last:border-0 transition-colors ${idx === highlightedIndex ? 'bg-cyan-50 text-cyan-950 font-medium' : 'text-slate-700 hover:bg-slate-50'
                  }`}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-semibold text-slate-900">{m.name}</span>
                    {m.strength && <span className="ml-1.5 text-xs font-semibold text-cyan-700">({m.strength})</span>}
                    {m.pack && <span className="ml-2 text-xs font-mono text-slate-500">[{m.pack}]</span>}
                    <span className="ml-2 text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-mono uppercase">{m.type}</span>
                  </div>
                  <span className="text-[11px] font-bold bg-cyan-100 text-cyan-800 px-2 py-0.5 rounded-full shrink-0">
                    GST {m.default_gst_percent}%
                  </span>
                </div>
                <div className="flex gap-3 text-[11px] text-slate-500 mt-1 font-sans items-center">
                  {m.generic_name && <span><strong className="text-slate-600">Gen:</strong> {m.generic_name}</span>}
                  {m.hsn_code && <span><strong className="text-slate-600">HSN:</strong> <code className="font-mono">{m.hsn_code}</code></span>}
                  {m.rack_no && (
                    <span className="font-mono font-bold bg-amber-50 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded">
                      Rack {m.rack_no}
                    </span>
                  )}
                </div>
              </li>
            ))
          )}
        </ul>
      )}
    </div>
  )
}

// Generic Free-Text Typeahead Combobox Component for Form Inputs
function FreeTextCombobox({
  value,
  onChange,
  options,
  placeholder,
  error,
  inputRef,
  onSelectOption
}: {
  value: string
  onChange: (val: string) => void
  options: Array<{ value: string; label?: string; meta?: string }>
  placeholder?: string
  error?: string
  inputRef?: React.RefObject<HTMLInputElement | null>
  onSelectOption?: (val: string) => void
}) {
  const [isOpen, setIsOpen] = useState(false)
  const [highlightedIndex, setHighlightedIndex] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const filtered = options.filter(
    (opt) =>
      opt.value.toLowerCase().includes((value || '').toLowerCase()) ||
      (opt.label && opt.label.toLowerCase().includes((value || '').toLowerCase()))
  )

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen && (e.key === 'ArrowDown' || e.key === 'Enter')) {
      if (options.length > 0) setIsOpen(true)
      return
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHighlightedIndex((prev) => (prev < filtered.length - 1 ? prev + 1 : prev))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlightedIndex((prev) => (prev > 0 ? prev - 1 : 0))
    } else if (e.key === 'Enter') {
      if (isOpen && filtered[highlightedIndex]) {
        e.preventDefault()
        const selected = filtered[highlightedIndex].value
        onChange(selected)
        if (onSelectOption) onSelectOption(selected)
        setIsOpen(false)
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false)
    }
  }

  return (
    <div ref={containerRef} className="relative w-full">
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={value}
          onFocus={() => setIsOpen(true)}
          onChange={(e) => {
            onChange(e.target.value)
            setIsOpen(true)
            setHighlightedIndex(0)
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className={`w-full py-2 pl-3 pr-8 text-sm rounded-xl border transition-all ${error
            ? 'border-red-300 bg-red-50/30 focus:ring-red-500'
            : 'border-slate-200 focus:ring-cyan-500'
            } focus:outline-none focus:ring-2`}
        />
        {options.length > 0 && (
          <ChevronDown
            onClick={() => setIsOpen(!isOpen)}
            className="absolute right-3 top-2.5 h-4 w-4 text-slate-400 cursor-pointer hover:text-slate-600 transition-colors"
          />
        )}
      </div>

      {error && <p className="text-[11px] text-red-500 mt-1 font-medium">{error}</p>}

      {isOpen && filtered.length > 0 && (
        <ul className="absolute z-50 mt-1 w-full max-h-48 overflow-y-auto rounded-xl bg-white border border-slate-200 shadow-xl py-1 text-sm">
          {filtered.map((opt, idx) => (
            <li
              key={idx}
              onMouseEnter={() => setHighlightedIndex(idx)}
              onClick={() => {
                onChange(opt.value)
                if (onSelectOption) onSelectOption(opt.value)
                setIsOpen(false)
              }}
              className={`px-3 py-2 cursor-pointer flex justify-between items-center transition-colors ${idx === highlightedIndex ? 'bg-cyan-50 text-cyan-900 font-semibold' : 'text-slate-700 hover:bg-slate-50'
                }`}
            >
              <div>
                <span className="font-medium text-slate-900">{opt.value}</span>
                {opt.label && <span className="ml-2 text-xs text-slate-500">({opt.label})</span>}
              </div>
              {opt.meta && <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-mono">{opt.meta}</span>}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

// Scrollable single-select dropdown (native <select> popups can't be styled/capped in height)
function ScrollableSelect({
  value,
  onChange,
  options
}: {
  value: string
  onChange: (val: string) => void
  options: Array<{ value: string; label: string }>
}) {
  const [isOpen, setIsOpen] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const selected = options.find((opt) => opt.value === value)

  return (
    <div ref={containerRef} className="relative w-full">
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-semibold text-slate-900 bg-white flex items-center justify-between cursor-pointer"
      >
        <span>{selected?.label || value}</span>
        <ChevronDown className={`h-4 w-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <ul className="absolute z-50 mt-1 w-full max-h-56 overflow-y-auto rounded-xl bg-white border border-slate-200 shadow-xl py-1 text-sm">
          {options.map((opt) => (
            <li
              key={opt.value}
              onClick={() => {
                onChange(opt.value)
                setIsOpen(false)
              }}
              className={`px-3 py-2 cursor-pointer transition-colors ${opt.value === value ? 'bg-cyan-50 text-cyan-900 font-semibold' : 'text-slate-700 hover:bg-slate-50'
                }`}
            >
              {opt.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

const DOSAGE_FORM_OPTIONS = [
  { value: 'TABLET', label: 'TABLET' },
  { value: 'CAPSULE', label: 'CAPSULE' },
  { value: 'INJECTION', label: 'INJECTION' },
  { value: 'SYRUP', label: 'SYRUP' },
  { value: 'OINTMENT', label: 'OINTMENT' },
  { value: 'SUSPENSION', label: 'SUSPENSION' },
  { value: 'DROP', label: 'DROP' },
  { value: 'GEL', label: 'GEL' },
  { value: 'LOTION', label: 'LOTION' },
  { value: 'POWDER', label: 'POWDER' },
  { value: 'OIL', label: 'OIL' },
  { value: 'FACE_WASH', label: 'FACE WASH' },
  { value: 'CREAM', label: 'CREAM' },
  { value: 'BALM', label: 'BALM' },
  { value: 'OTHER', label: 'OTHER' }
]

// Indian GST State Code Map for Auto-Detection
const INDIAN_GST_STATE_CODES: Record<string, string> = {
  '01': 'Jammu & Kashmir',
  '02': 'Himachal Pradesh',
  '03': 'Punjab',
  '04': 'Chandigarh',
  '05': 'Uttarakhand',
  '06': 'Haryana',
  '07': 'Delhi',
  '08': 'Rajasthan',
  '09': 'Uttar Pradesh',
  '10': 'Bihar',
  '11': 'Sikkim',
  '12': 'Arunachal Pradesh',
  '13': 'Nagaland',
  '14': 'Manipur',
  '15': 'Mizoram',
  '16': 'Tripura',
  '17': 'Meghalaya',
  '18': 'Assam',
  '19': 'West Bengal',
  '20': 'Jharkhand',
  '21': 'Odisha',
  '22': 'Chhattisgarh',
  '23': 'Madhya Pradesh',
  '24': 'Gujarat',
  '25': 'Daman & Diu',
  '26': 'Dadra & Nagar Haveli',
  '27': 'Maharashtra',
  '28': 'Andhra Pradesh (Old)',
  '29': 'Karnataka',
  '30': 'Goa',
  '31': 'Lakshadweep',
  '32': 'Kerala',
  '33': 'Tamil Nadu',
  '34': 'Puducherry',
  '36': 'Telangana',
  '37': 'Andhra Pradesh'
}

const getSmartPackagingDefaults = (dosageType: string) => {
  switch ((dosageType || '').toUpperCase()) {
    case 'TABLET':
      return { baseUnit: 'Tablet', innerUnit: 'Strip', unitsPerInner: '10', purchaseUnit: 'Box', innerUnitsPerPurchase: '10' }
    case 'CAPSULE':
      return { baseUnit: 'Capsule', innerUnit: 'Strip', unitsPerInner: '10', purchaseUnit: 'Box', innerUnitsPerPurchase: '10' }
    case 'INJECTION':
      return { baseUnit: 'Vial', innerUnit: 'Vial', unitsPerInner: '1', purchaseUnit: 'Box', innerUnitsPerPurchase: '10' }
    case 'SYRUP':
    case 'SUSPENSION':
    case 'DROP':
    case 'LOTION':
    case 'OIL':
      return { baseUnit: 'Bottle', innerUnit: 'Bottle', unitsPerInner: '1', purchaseUnit: 'Box', innerUnitsPerPurchase: '10' }
    case 'OINTMENT':
    case 'GEL':
    case 'CREAM':
    case 'BALM':
    case 'FACE_WASH':
      return { baseUnit: 'Tube', innerUnit: 'Tube', unitsPerInner: '1', purchaseUnit: 'Box', innerUnitsPerPurchase: '10' }
    case 'POWDER':
      return { baseUnit: 'Sachet', innerUnit: 'Sachet', unitsPerInner: '1', purchaseUnit: 'Box', innerUnitsPerPurchase: '10' }
    default:
      return { baseUnit: 'Piece', innerUnit: 'Strip', unitsPerInner: '10', purchaseUnit: 'Box', innerUnitsPerPurchase: '10' }
  }
}

// Redesigned Add / Edit Medicine Form Modal Component
function RedesignedMedicineModal({
  isOpen,
  onClose,
  onSubmit,
  editingMed,
  existingMedicines,
  initialFormValues
}: {
  isOpen: boolean
  onClose: () => void
  onSubmit: (formData: any) => Promise<void>
  editingMed: Medicine | null
  existingMedicines: Medicine[]
  initialFormValues?: Partial<{
    name: string
    strength: string
    genericName: string
    manufacturer: string
    pack: string
    type: string
    unitLabel: string
    hsnCode: string
    rackNo: string
    reorderLevel: string
    defaultGstPercent: string
  }>
}) {
  const [form, setForm] = useState({
    name: '',
    strength: '',
    genericName: '',
    manufacturer: '',
    pack: '',
    type: 'TABLET',
    unitLabel: 'strip',
    baseUnit: 'Tablet',
    innerUnit: 'Strip',
    unitsPerInner: '10',
    purchaseUnit: 'Box',
    innerUnitsPerPurchase: '10',
    hsnCode: '',
    rackNo: '',
    reorderLevel: '10',
    defaultGstPercent: '12'
  })

  const [submitting, setSubmitting] = useState(false)
  const nameInputRef = useRef<HTMLInputElement>(null)

  // Initialize form when modal opens or editingMed/initialFormValues change
  useEffect(() => {
    if (isOpen) {
      if (editingMed) {
        const defaults = getSmartPackagingDefaults(editingMed.type || 'TABLET')
        setForm({
          name: editingMed.name || '',
          strength: editingMed.strength || '',
          genericName: editingMed.generic_name || '',
          manufacturer: editingMed.manufacturer || '',
          pack: editingMed.pack || '',
          type: editingMed.type || 'TABLET',
          unitLabel: editingMed.unit_label || 'strip',
          baseUnit: editingMed.base_unit || defaults.baseUnit,
          innerUnit: editingMed.inner_unit || defaults.innerUnit,
          unitsPerInner: (editingMed.units_per_inner ?? parseFloat(defaults.unitsPerInner)).toString(),
          purchaseUnit: editingMed.purchase_unit || defaults.purchaseUnit,
          innerUnitsPerPurchase: (editingMed.inner_units_per_purchase ?? parseFloat(defaults.innerUnitsPerPurchase)).toString(),
          hsnCode: editingMed.hsn_code || '',
          rackNo: editingMed.rack_no || '',
          reorderLevel: (editingMed.reorder_level ?? 10).toString(),
          defaultGstPercent: (editingMed.default_gst_percent ?? 12).toString()
        })
      } else if (initialFormValues) {
        const defaults = getSmartPackagingDefaults(initialFormValues.type || 'TABLET')
        setForm({
          name: initialFormValues.name || '',
          strength: initialFormValues.strength || '',
          genericName: initialFormValues.genericName || '',
          manufacturer: initialFormValues.manufacturer || '',
          pack: initialFormValues.pack || '',
          type: initialFormValues.type || 'TABLET',
          unitLabel: initialFormValues.unitLabel || 'strip',
          baseUnit: defaults.baseUnit,
          innerUnit: defaults.innerUnit,
          unitsPerInner: defaults.unitsPerInner,
          purchaseUnit: defaults.purchaseUnit,
          innerUnitsPerPurchase: defaults.innerUnitsPerPurchase,
          hsnCode: initialFormValues.hsnCode || '',
          rackNo: initialFormValues.rackNo || '',
          reorderLevel: initialFormValues.reorderLevel || '10',
          defaultGstPercent: initialFormValues.defaultGstPercent || '12'
        })
      } else {
        const defaults = getSmartPackagingDefaults('TABLET')
        setForm({
          name: '',
          strength: '',
          genericName: '',
          manufacturer: '',
          pack: '',
          type: 'TABLET',
          unitLabel: 'strip',
          baseUnit: defaults.baseUnit,
          innerUnit: defaults.innerUnit,
          unitsPerInner: defaults.unitsPerInner,
          purchaseUnit: defaults.purchaseUnit,
          innerUnitsPerPurchase: defaults.innerUnitsPerPurchase,
          hsnCode: '',
          rackNo: '',
          reorderLevel: '10',
          defaultGstPercent: '12'
        })
      }

      // Auto-focus Medicine Name input on open
      setTimeout(() => {
        nameInputRef.current?.focus()
      }, 100)
    }
  }, [isOpen, editingMed, initialFormValues])

  if (!isOpen) return null

  // Collect unique Generic Names from existing medicines for Combobox
  const genericOptions = Array.from(
    new Set(existingMedicines.map((m) => m.generic_name).filter(Boolean) as string[])
  ).map((g) => ({ value: g }))

  // Collect unique Manufacturers from existing medicines for Combobox
  const manufacturerOptions = Array.from(
    new Set(existingMedicines.map((m) => m.manufacturer).filter(Boolean) as string[])
  ).map((m) => ({ value: m }))

  // Collect unique HSN codes + standard pharma HSNs with GST slab hints
  const standardPharmaHsns = [
    { value: '3004', label: 'Medicaments (Tablets/Capsules/Syrups)', meta: '12% GST' },
    { value: '300490', label: 'Other Medicaments', meta: '12% GST' },
    { value: '3005', label: 'Wadding, Gauze, Bandages', meta: '12% GST' },
    { value: '3006', label: 'Pharmaceutical Preparations', meta: '12% GST' },
    { value: '3002', label: 'Vaccines, Sera, Toxins', meta: '5% GST' },
    { value: '3003', label: 'Bulk Medicaments', meta: '12% GST' }
  ]
  const usedHsns = Array.from(
    new Set(existingMedicines.map((m) => m.hsn_code).filter(Boolean) as string[])
  ).map((hsn) => ({ value: hsn, label: 'Used in Inventory' }))

  const hsnOptions = [...standardPharmaHsns, ...usedHsns.filter(u => !standardPharmaHsns.some(s => s.value === u.value))]

  // HSN Auto-GST Mapper Callback
  const handleSelectHsn = (selectedHsn: string) => {
    let suggestedGst = ''
    if (selectedHsn.startsWith('3002') || selectedHsn.startsWith('3001')) {
      suggestedGst = '5'
    } else if (selectedHsn.startsWith('3004') || selectedHsn.startsWith('3005') || selectedHsn.startsWith('3006') || selectedHsn.startsWith('3003')) {
      suggestedGst = '12'
    }
    if (suggestedGst) {
      setForm((prev) => ({ ...prev, hsnCode: selectedHsn, defaultGstPercent: suggestedGst }))
    } else {
      setForm((prev) => ({ ...prev, hsnCode: selectedHsn }))
    }
  }

  // Contextually adapt Unit Label options based on selected Type
  const adaptiveUnitLabels: Record<string, string[]> = {
    TABLET: ['strip', 'pcs', 'box', 'tablet'],
    CAPSULE: ['strip', 'pcs', 'box', 'capsule'],
    INJECTION: ['vial', 'ampoule', 'pcs', 'box'],
    SYRUP: ['bottle', 'ml', 'pcs'],
    OINTMENT: ['tube', 'gm', 'pcs'],
    SUSPENSION: ['bottle', 'ml', 'pcs'],
    DROP: ['bottle', 'ml', 'pcs'],
    GEL: ['tube', 'gm', 'pcs'],
    LOTION: ['bottle', 'ml', 'pcs'],
    POWDER: ['bottle', 'gm', 'sachet', 'pcs'],
    OIL: ['bottle', 'ml', 'pcs'],
    FACE_WASH: ['tube', 'ml', 'pcs'],
    CREAM: ['tube', 'gm', 'pcs'],
    BALM: ['tube', 'gm', 'pcs'],
    OTHER: ['pcs', 'bottle', 'box', 'pack']
  }
  const currentUnitOptions = adaptiveUnitLabels[form.type] || ['strip', 'vial', 'bottle', 'pcs']

  // Helper for string normalization
  const normStr = (str?: string | null) => {
    if (!str) return ''
    const s = str.trim().replace(/\s+/g, ' ')
    if (s.toUpperCase() === 'NULL' || s.toUpperCase() === 'UNDEFINED') return ''
    return s.toUpperCase()
  }

  // 5-Tuple Duplicate Combination Check (Name + Strength + Dosage Form + Pack Size + Manufacturer)
  const cleanInputName = normStr(form.name)
  const cleanInputStrength = normStr(form.strength)
  const cleanInputType = normStr(form.type) || 'TABLET'
  const cleanInputPack = normStr(form.pack)
  const cleanInputManufacturer = normStr(form.manufacturer)

  const duplicateMedMatch = cleanInputName.length > 0
    ? existingMedicines.find(
      (m) =>
        m.id !== editingMed?.id &&
        normStr(m.name) === cleanInputName &&
        normStr(m.strength) === cleanInputStrength &&
        (normStr(m.type) || 'TABLET') === cleanInputType &&
        normStr(m.pack) === cleanInputPack &&
        normStr(m.manufacturer) === cleanInputManufacturer
    )
    : null

  // Validations
  const isNameValid = Boolean(form.name.trim()) && !duplicateMedMatch
  const reorderNum = parseInt(form.reorderLevel)
  const isReorderValid = !isNaN(reorderNum) && reorderNum >= 0
  const gstNum = parseFloat(form.defaultGstPercent)
  const isGstValid = !isNaN(gstNum) && gstNum >= 0 && gstNum <= 100

  const isValid = isNameValid && isReorderValid && isGstValid

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault()
    if (duplicateMedMatch) {
      toast.error(`Duplicate Medicine Combination (Name + Strength + Dosage Form + Pack + Manufacturer) is not allowed!`)
      return
    }
    if (!isValid || submitting) return
    setSubmitting(true)
    try {
      await onSubmit({
        ...form,
        name: cleanInputName,
        strength: cleanInputStrength,
        type: cleanInputType,
        pack: cleanInputPack,
        manufacturer: cleanInputManufacturer,
        base_unit: form.baseUnit || 'Piece',
        inner_unit: form.innerUnit || null,
        units_per_inner: parseFloat(form.unitsPerInner) || 1.0,
        purchase_unit: form.purchaseUnit || null,
        inner_units_per_purchase: parseFloat(form.innerUnitsPerPurchase) || 1.0
      })
    } finally {
      setSubmitting(false)
    }
  }

  // Keyboard Navigation: Ctrl+Enter to save, Esc to cancel
  const handleFormKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault()
      handleSubmit()
    } else if (e.key === 'Escape') {
      e.preventDefault()
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div
        onKeyDown={handleFormKeyDown}
        className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-100 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* MODAL HEADER */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <h3 className="text-md font-bold">
              {editingMed ? 'Edit Medicine Master' : 'Add New Medicine Master'}
            </h3>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">Ctrl+Enter to Save</span>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* MODAL FORM BODY */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 text-slate-800">

          {/* SECTION 1: MEDICINE IDENTIFICATION */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-wider text-cyan-700">
              <Tag className="w-4 h-4 text-cyan-500" /> 1. Medicine Identification
            </div>

            <div className="space-y-3">
              {/* Medicine Name & Strength inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                    Medicine Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    ref={nameInputRef}
                    type="text"
                    placeholder="e.g. PARACETAMOL or DOLOMED"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value.toUpperCase() })}
                    className={`w-full py-2 px-3 rounded-xl border text-sm focus:outline-none focus:ring-2 font-semibold uppercase ${!isNameValid && form.name !== ''
                      ? 'border-red-300 bg-red-50/20 focus:ring-red-500'
                      : 'border-slate-200 focus:ring-cyan-500'
                      }`}
                  />
                  {!Boolean(form.name.trim()) && (
                    <p className="text-[11px] text-red-500 mt-1 font-medium">Medicine name is required.</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                    Strength
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 500mg, 10ml, 500IU"
                    value={form.strength}
                    onChange={(e) => setForm({ ...form, strength: e.target.value })}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-semibold"
                  />
                </div>
              </div>

              {/* DUPLICATE MEDICINE RESTRICTION ERROR */}
              {duplicateMedMatch && (
                <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs flex items-start gap-2 text-red-900">
                  <ShieldAlert className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Duplicate Medicine Combination Restricted!</span>
                    <div className="text-[11px] text-red-800 mt-0.5 leading-relaxed">
                      A medicine with combination: Name <strong className="text-red-950">"{duplicateMedMatch.name}"</strong>
                      {duplicateMedMatch.strength && <>, Strength <strong className="text-red-950">"{duplicateMedMatch.strength}"</strong></>}
                      , Form <strong className="text-red-950">"{duplicateMedMatch.type}"</strong>
                      {duplicateMedMatch.pack && <>, Pack <strong className="text-red-950">"{duplicateMedMatch.pack}"</strong></>}
                      {duplicateMedMatch.manufacturer && <>, Manufacturer <strong className="text-red-950">"{duplicateMedMatch.manufacturer}"</strong></>}
                      {' '}already exists. Duplicate combination entries are not allowed.
                    </div>
                  </div>
                </div>
              )}

              {/* Generic Name */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                  Generic Name / Formula
                </label>
                <FreeTextCombobox
                  value={form.genericName}
                  onChange={(val) => setForm({ ...form, genericName: val })}
                  options={genericOptions}
                  placeholder="e.g. Paracetamol, Amoxicillin"
                />
              </div>

              {/* Dosage Form & Pack Size */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                    Dosage Form <span className="text-red-500">*</span>
                  </label>
                  <ScrollableSelect
                    value={form.type}
                    onChange={(val) => {
                      const defaults = getSmartPackagingDefaults(val)
                      const defaultUnit = adaptiveUnitLabels[val]?.[0] || 'strip'
                      setForm({
                        ...form,
                        type: val,
                        unitLabel: defaultUnit,
                        baseUnit: defaults.baseUnit,
                        innerUnit: defaults.innerUnit,
                        unitsPerInner: defaults.unitsPerInner,
                        purchaseUnit: defaults.purchaseUnit,
                        innerUnitsPerPurchase: defaults.innerUnitsPerPurchase
                      })
                    }}
                    options={DOSAGE_FORM_OPTIONS}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                    Pack Size / Description
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 10x10 Strips, 100ml Bottle"
                    value={form.pack}
                    onChange={(e) => setForm({ ...form, pack: e.target.value })}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-semibold"
                  />
                </div>
              </div>

              {/* Manufacturer */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                  Manufacturer / Brand
                </label>
                <FreeTextCombobox
                  value={form.manufacturer}
                  onChange={(val) => setForm({ ...form, manufacturer: val })}
                  options={manufacturerOptions}
                  placeholder="e.g. Cipla, Sun Pharma, Mankind"
                />
              </div>
            </div>
          </div>

          {/* SECTION 2: INVENTORY & COMPLIANCE */}
          <div className="space-y-4 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-wider text-cyan-700">
              <Package className="w-4 h-4 text-cyan-500" /> 2. Inventory & Compliance
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* HSN Code Combobox */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                  HSN Code <span className="text-slate-400 font-normal">(Auto-fills GST%)</span>
                </label>
                <FreeTextCombobox
                  value={form.hsnCode}
                  onChange={(val) => setForm({ ...form, hsnCode: val })}
                  onSelectOption={handleSelectHsn}
                  options={hsnOptions}
                  placeholder="e.g. 300490"
                />
              </div>

              {/* Reorder Level */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                  Reorder Alert Level <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  placeholder="10"
                  value={form.reorderLevel}
                  onChange={(e) => setForm({ ...form, reorderLevel: e.target.value })}
                  className={`w-full py-2 px-3 rounded-xl border text-sm focus:outline-none focus:ring-2 font-mono ${!isReorderValid
                    ? 'border-red-300 bg-red-50/20 focus:ring-red-500'
                    : 'border-slate-200 focus:ring-cyan-500'
                    }`}
                />
                {!isReorderValid && (
                  <p className="text-[11px] text-red-500 mt-1 font-medium">Must be an integer ≥ 0.</p>
                )}
              </div>
            </div>

            {/* Default GST% with Quick-Pick Slab Chips */}
            <div>
              <label className="block text-xs font-bold text-slate-600 uppercase mb-1 flex justify-between items-center">
                <span>Default GST Rate (%) <span className="text-red-500">*</span></span>
                <span className="text-[11px] text-slate-400 font-normal font-sans">Click chip or type percentage</span>
              </label>

              <div className="flex flex-wrap items-center gap-2 mb-2">
                {['0', '5', '12', '18', '28'].map((slab) => (
                  <button
                    key={slab}
                    type="button"
                    onClick={() => setForm({ ...form, defaultGstPercent: slab })}
                    className={`px-3 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer ${form.defaultGstPercent === slab
                      ? 'bg-cyan-600 text-white border-cyan-600 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                  >
                    {slab}% GST
                  </button>
                ))}
              </div>

              <input
                type="number"
                step="0.01"
                placeholder="12"
                value={form.defaultGstPercent}
                onChange={(e) => setForm({ ...form, defaultGstPercent: e.target.value })}
                className={`w-full py-2 px-3 rounded-xl border text-sm focus:outline-none focus:ring-2 font-mono font-bold ${!isGstValid
                  ? 'border-red-300 bg-red-50/20 focus:ring-red-500'
                  : 'border-slate-200 focus:ring-cyan-500'
                  }`}
              />
              {!isGstValid && (
                <p className="text-[11px] text-red-500 mt-1 font-medium">Valid GST rate between 0% and 100% required.</p>
              )}
            </div>
          </div>

          {/* SECTION 3: PHARMACY PACKAGING SETUP */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-700">
                <Layers className="w-4 h-4 text-cyan-500" /> 3. Pharmacy Packaging Setup
              </div>
              <span className="text-[11px] text-cyan-700 font-semibold bg-cyan-50 px-2 py-0.5 rounded border border-cyan-200/60">
                Auto-configured for {form.type}
              </span>
            </div>

            <div className="p-4 bg-slate-50/90 border border-slate-200/90 rounded-2xl space-y-3.5">
              {/* Physical Packing Rule Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* 1. Primary Packaging Ratio */}
                <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs space-y-2">
                  <label className="block text-xs font-bold text-slate-800 uppercase">
                    1. Primary Pack Ratio <span className="text-cyan-600 lowercase font-normal">(e.g. Strip size)</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-1.5 rounded-lg whitespace-nowrap font-mono">
                      1 {form.innerUnit || 'Strip'} =
                    </span>
                    <input
                      type="number"
                      step="any"
                      placeholder="10"
                      value={form.unitsPerInner}
                      onChange={(e) => setForm({ ...form, unitsPerInner: e.target.value })}
                      className="w-20 py-1.5 px-2.5 rounded-lg border border-slate-300 text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-cyan-500 bg-white"
                    />
                    <select
                      value={form.baseUnit}
                      onChange={(e) => setForm({ ...form, baseUnit: e.target.value })}
                      className="text-xs font-bold text-slate-800 py-1.5 px-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    >
                      {['Tablet', 'Capsule', 'Piece', 'Vial', 'Bottle', 'Ampoule', 'Tube', 'Sachet', 'Dose', 'ml', 'gm'].map(u => (
                        <option key={u} value={u}>{u}s</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* 2. Outer Box Ratio */}
                <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-2xs space-y-2">
                  <label className="block text-xs font-bold text-slate-800 uppercase">
                    2. Wholesale Box Ratio <span className="text-cyan-600 lowercase font-normal">(Distributor bill)</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-1.5 rounded-lg whitespace-nowrap font-mono">
                      1 Box =
                    </span>
                    <input
                      type="number"
                      step="any"
                      placeholder="10"
                      value={form.innerUnitsPerPurchase}
                      onChange={(e) => setForm({ ...form, innerUnitsPerPurchase: e.target.value })}
                      className="w-20 py-1.5 px-2.5 rounded-lg border border-slate-300 text-sm font-mono font-bold focus:outline-none focus:ring-2 focus:ring-cyan-500 bg-white"
                    />
                    <select
                      value={form.innerUnit}
                      onChange={(e) => setForm({ ...form, innerUnit: e.target.value })}
                      className="text-xs font-bold text-slate-800 py-1.5 px-2 rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    >
                      {['Strip', 'Box', 'Bottle', 'Vial', 'Ampoule', 'Tube', 'Sachet', 'Pack', 'Piece'].map(u => (
                        <option key={u} value={u}>{u}s</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* LIVE CONVERSION SUMMARY */}
              <div className="p-3 bg-cyan-900 text-white rounded-xl flex items-center justify-between shadow-xs">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-cyan-300 shrink-0" />
                  <div>
                    <span className="font-bold uppercase tracking-wider text-[10px] text-cyan-200 block">Automatic Packaging Calculation</span>
                    <span className="font-mono font-bold text-sm text-cyan-100">
                      {getLiveConversionSummary({
                        base_unit: form.baseUnit,
                        inner_unit: form.innerUnit,
                        units_per_inner: parseFloat(form.unitsPerInner) || 1,
                        purchase_unit: form.purchaseUnit,
                        inner_units_per_purchase: parseFloat(form.innerUnitsPerPurchase) || 1
                      })}
                    </span>
                  </div>
                </div>
                <span className="text-[11px] font-semibold bg-cyan-800 text-cyan-200 px-2.5 py-1 rounded-lg border border-cyan-700">
                  Ready for Stock & Billing
                </span>
              </div>
            </div>
          </div>

          {/* FOOTER ACTIONS */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel (Esc)
            </button>

            <div className="relative group">
              <button
                type="submit"
                disabled={!isValid || submitting}
                className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-600 text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-md shadow-cyan-500/20 transition-all disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none cursor-pointer flex items-center gap-1.5"
              >
                {submitting ? (
                  <span>Saving...</span>
                ) : (
                  <>
                    <Check className="w-4 h-4" /> Save Medicine
                  </>
                )}
              </button>

              {/* Disabled tooltip */}
              {!isValid && (
                <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-52 p-2 bg-slate-900 text-slate-200 text-xs rounded-lg shadow-xl z-50">
                  <p className="font-semibold text-amber-400 mb-1">Cannot save yet:</p>
                  <ul className="list-disc pl-4 space-y-0.5 text-[11px]">
                    {!isNameValid && <li>Medicine name required</li>}
                    {!isReorderValid && <li>Reorder level must be ≥ 0</li>}
                    {!isGstValid && <li>Default GST % required</li>}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

// Redesigned Add / Edit Vendor Form Modal Component
function RedesignedVendorModal({
  isOpen,
  onClose,
  onSubmit,
  editingVendor,
  existingVendors,
  initialFormValues
}: {
  isOpen: boolean
  onClose: () => void
  onSubmit: (formData: any) => Promise<void>
  editingVendor: Vendor | null
  existingVendors: Vendor[]
  initialFormValues?: Partial<{
    name: string
    phone: string
    address: string
    gstin: string
    drug_license_no: string
    notes: string
  }>
}) {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    address: '',
    gstin: '',
    drug_license_no: '',
    notes: ''
  })

  const [submitting, setSubmitting] = useState(false)
  const nameInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (isOpen) {
      if (editingVendor) {
        setForm({
          name: editingVendor.name || '',
          phone: editingVendor.phone || '',
          address: editingVendor.address || '',
          gstin: editingVendor.gstin || '',
          drug_license_no: editingVendor.drug_license_no || '',
          notes: editingVendor.notes || ''
        })
      } else if (initialFormValues) {
        setForm({
          name: initialFormValues.name || '',
          phone: initialFormValues.phone || '',
          address: initialFormValues.address || '',
          gstin: initialFormValues.gstin || '',
          drug_license_no: initialFormValues.drug_license_no || '',
          notes: initialFormValues.notes || ''
        })
      } else {
        setForm({
          name: '',
          phone: '',
          address: '',
          gstin: '',
          drug_license_no: '',
          notes: ''
        })
      }

      setTimeout(() => {
        nameInputRef.current?.focus()
      }, 100)
    }
  }, [isOpen, editingVendor, initialFormValues])

  if (!isOpen) return null

  // Phone & GSTIN Clean Values
  const cleanPhone = form.phone.trim()
  const cleanGstin = form.gstin.trim().toUpperCase()

  // Duplicate Vendor Warning (Blocking)
  const cleanVendorInputName = form.name.trim().replace(/\s+/g, ' ').toUpperCase()
  const duplicateVendor = (cleanVendorInputName.length > 0 || cleanGstin.length === 15)
    ? existingVendors.find(
      (v) =>
        v.id !== editingVendor?.id &&
        ((cleanVendorInputName.length > 0 && v.name.trim().replace(/\s+/g, ' ').toUpperCase() === cleanVendorInputName) ||
          (cleanGstin.length === 15 && v.gstin && v.gstin.toUpperCase() === cleanGstin))
    )
    : null

  // Validations
  const isNameValid = Boolean(form.name.trim()) && !duplicateVendor

  // Phone Validation (Mobile or Telephone / Landline, optional when blank)
  const digitsOnlyPhone = cleanPhone.replace(/[\s\-\(\)\+]/g, '')
  const isPhoneValid = cleanPhone === '' || (digitsOnlyPhone.length >= 6 && digitsOnlyPhone.length <= 15 && /^[\+\d\s\-\(\)]+$/.test(cleanPhone))

  // GSTIN Validation (15-character format, optional when blank)
  const gstinPattern = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/
  const isGstinValid = cleanGstin === '' || (cleanGstin.length === 15 && gstinPattern.test(cleanGstin))

  // State Detection from GSTIN (First 2 digits)
  const stateCode = cleanGstin.length >= 2 ? cleanGstin.substring(0, 2) : ''
  const detectedState = INDIAN_GST_STATE_CODES[stateCode] || null

  // Overall Form Validation State
  const isValid = isNameValid && isPhoneValid && isGstinValid

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault()
    if (duplicateVendor) {
      toast.error(`Duplicate Vendor Name "${duplicateVendor.name}" is not allowed!`)
      return
    }
    if (!isValid || submitting) return
    setSubmitting(true)
    try {
      await onSubmit({
        name: cleanVendorInputName,
        phone: cleanPhone,
        address: form.address,
        gstin: cleanGstin,
        drug_license_no: form.drug_license_no.trim().toUpperCase(),
        notes: form.notes
      })
    } finally {
      setSubmitting(false)
    }
  }

  const handleFormKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault()
      handleSubmit()
    } else if (e.key === 'Escape') {
      e.preventDefault()
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div
        onKeyDown={handleFormKeyDown}
        className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-100 overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* MODAL HEADER */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-5 h-5 text-cyan-400" />
            <h3 className="text-md font-bold">
              {editingVendor ? 'Edit Vendor Master' : 'Add New Vendor Master'}
            </h3>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">Ctrl+Enter to Save</span>
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* MODAL FORM BODY */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6 text-slate-800">

          {/* SECTION 1: CONTACT & LOCATION */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-wider text-cyan-700">
              <Building2 className="w-4 h-4 text-cyan-500" /> 1. Vendor Contact & Location
            </div>

            <div className="space-y-3">
              {/* Vendor Name */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">
                  Vendor Name <span className="text-red-500">*</span>
                </label>
                <input
                  ref={nameInputRef}
                  type="text"
                  placeholder="e.g. APEX PHARMACY WHOLESALE"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value.toUpperCase() })}
                  className={`w-full py-2 px-3 rounded-xl border text-sm focus:outline-none focus:ring-2 font-semibold uppercase ${!isNameValid && form.name !== ''
                    ? 'border-red-300 bg-red-50/20 focus:ring-red-500'
                    : 'border-slate-200 focus:ring-cyan-500'
                    }`}
                />
                {!Boolean(form.name.trim()) && (
                  <p className="text-[11px] text-red-500 mt-1 font-medium">Vendor name is required.</p>
                )}

                {/* DUPLICATE VENDOR RESTRICTION ERROR */}
                {duplicateVendor && (
                  <div className="mt-2 p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs flex items-start gap-2 text-red-900">
                    <ShieldAlert className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Duplicate Vendor Restricted!</span>
                      <div className="text-[11px] text-red-800 mt-0.5">
                        Vendor with name <strong className="text-red-950">"{duplicateVendor.name}"</strong> already exists. Duplicate entries are not allowed.
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Phone Number */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1 flex justify-between">
                  <span>Phone / Telephone No.</span>
                  <span className="text-[11px] text-slate-400 font-normal font-sans">Mobile or Landline</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. 9876543210 or 022-28491234"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className={`w-full py-2 px-3 rounded-xl border text-sm focus:outline-none focus:ring-2 font-mono ${!isPhoneValid
                    ? 'border-red-300 bg-red-50/20 focus:ring-red-500'
                    : 'border-slate-200 focus:ring-cyan-500'
                    }`}
                />
                {!isPhoneValid && (
                  <p className="text-[11px] text-red-500 mt-1 font-medium">Must be a valid mobile or landline/telephone number.</p>
                )}
              </div>

              {/* Address */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Address / Location</label>
                <input
                  type="text"
                  placeholder="Vendor business address or city..."
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Notes / Remarks</label>
                <textarea
                  rows={2}
                  placeholder="Optional payment terms, contact person, or notes..."
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                />
              </div>
            </div>
          </div>

          {/* SECTION 2: COMPLIANCE & LICENSING */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-2 text-xs font-bold uppercase tracking-wider text-cyan-700">
              <ShieldCheck className="w-4 h-4 text-cyan-500" /> 2. Tax Compliance & Drug Licensing
            </div>

            <div className="space-y-3">
              {/* GSTIN */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1 flex justify-between">
                  <span>GSTIN Number</span>
                  <span className="text-[11px] text-slate-400 font-normal font-sans">15-char format</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. 27AAAAA1111A1Z1"
                  value={form.gstin}
                  onChange={(e) => setForm({ ...form, gstin: e.target.value.toUpperCase() })}
                  className={`w-full py-2 px-3 rounded-xl border text-sm focus:outline-none focus:ring-2 font-mono font-semibold uppercase ${!isGstinValid
                    ? 'border-red-300 bg-red-50/20 focus:ring-red-500'
                    : 'border-slate-200 focus:ring-cyan-500'
                    }`}
                />
                {!isGstinValid && (
                  <p className="text-[11px] text-red-500 mt-1 font-medium">
                    Invalid 15-character GSTIN format (e.g. 27AAAAA1111A1Z1).
                  </p>
                )}

                {/* STATE AUTO-DETECTION BADGE */}
                {detectedState && isGstinValid && (
                  <div className="mt-2 p-2 bg-cyan-50 border border-cyan-200/70 rounded-lg text-xs font-medium text-cyan-900 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-cyan-600 shrink-0" />
                    <span>
                      Detected State: <strong className="text-cyan-950">{detectedState}</strong> (Code {stateCode}) • Enables In-State vs Inter-State Tax
                    </span>
                  </div>
                )}
              </div>

              {/* Drug License No */}
              <div>
                <label className="block text-xs font-bold text-slate-600 uppercase mb-1 flex justify-between">
                  <span>Drug License Number</span>
                  <span className="text-[11px] text-slate-400 font-normal font-sans">Format hint: DL-XXXXX/YYYY</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. DL-12345/2026"
                  value={form.drug_license_no}
                  onChange={(e) => setForm({ ...form, drug_license_no: e.target.value.toUpperCase() })}
                  className="w-full py-2 px-3 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono uppercase"
                />
              </div>
            </div>
          </div>

          {/* FOOTER ACTIONS */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors cursor-pointer"
            >
              Cancel (Esc)
            </button>

            <div className="relative group">
              <button
                type="submit"
                disabled={!isValid || submitting}
                className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-600 text-white rounded-xl text-xs font-bold uppercase tracking-wider shadow-md shadow-cyan-500/20 transition-all disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none cursor-pointer flex items-center gap-1.5"
              >
                {submitting ? (
                  <span>Saving...</span>
                ) : (
                  <>
                    <Check className="w-4 h-4" /> Save Vendor
                  </>
                )}
              </button>

              {/* Disabled tooltip */}
              {!isValid && (
                <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-56 p-2 bg-slate-900 text-slate-200 text-xs rounded-lg shadow-xl z-50">
                  <p className="font-semibold text-amber-400 mb-1">Cannot save yet:</p>
                  <ul className="list-disc pl-4 space-y-0.5 text-[11px]">
                    {!isNameValid && <li>Vendor name required</li>}
                    {!isPhoneValid && <li>Phone must be a valid mobile or landline number</li>}
                    {!isGstinValid && <li>GSTIN format invalid</li>}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}

export default function Inventory() {
  const medicines = useInventoryStore((state) => state.medicines)
  const vendors = useInventoryStore((state) => state.vendors)
  const batches = useInventoryStore((state) => state.batches)
  const purchases = useInventoryStore((state) => state.purchases)
  const loading = useInventoryStore((state) => state.loading)

  const loadAllData = useInventoryStore((state) => state.loadAllData)
  const createMedicine = useInventoryStore((state) => state.createMedicine)
  const updateMedicine = useInventoryStore((state) => state.updateMedicine)
  const deleteMedicine = useInventoryStore((state) => state.deleteMedicine)

  const createVendor = useInventoryStore((state) => state.createVendor)
  const updateVendor = useInventoryStore((state) => state.updateVendor)
  const deleteVendor = useInventoryStore((state) => state.deleteVendor)

  const createPurchase = useInventoryStore((state) => state.createPurchase)
  const adjustStock = useInventoryStore((state) => state.adjustStock)

  const currentUser = useAuthStore((state) => state.user)

  const [localTab, setLocalTab] = useState('stock-in') // default to stock-in for quick access
  const [searchQuery, setSearchQuery] = useState('')

  // Toast feedback helper
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    if (type === 'error') toast.error(message)
    else if (type === 'info') toast.info(message)
    else toast.success(message)
  }

  // Modals state
  const [showMedModal, setShowMedModal] = useState(false)
  const [editingMed, setEditingMed] = useState<Medicine | null>(null)

  const [showVendorModal, setShowVendorModal] = useState(false)
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null)

  const [showAdjustModal, setShowAdjustModal] = useState(false)
  const [selectedBatch, setSelectedBatch] = useState<InventoryBatch | null>(null)
  const [adjustQty, setAdjustQty] = useState('')
  const [adjustReason, setAdjustReason] = useState('Count correction')

  const [selectedPurchase, setSelectedPurchase] = useState<any | null>(null)

  // Stock In Form State
  const [purchaseForm, setPurchaseForm] = useState({
    vendorId: '',
    purchaseInvoiceNo: '',
    purchaseDate: new Date().toISOString().split('T')[0],
    purchaseType: 'CASH',
    taxType: 'INTRASTATE', // INTRASTATE (CGST+SGST) / INTERSTATE (IGST)
    dueDate: '',
    paymentDate: new Date().toISOString().split('T')[0],
    paidAmount: '',
    paymentStatus: 'PAID',
    paymentMode: 'CASH',
    notes: '',
    items: [] as Array<{
      medicineId: string
      batchNo: string
      expiryDate: string
      qtyPurchased: number
      freeQty: number
      mrp: number
      discountPercent: number
      taxableAmount: number
      cgstAmount: number
      sgstAmount: number
      igstAmount: number
      gstPercent: number
      purchasePricePerUnit: number
      sellingPricePerUnit: number
    }>
  })

  const [stockInItem, setStockInItem] = useState({
    medicineId: '',
    batchNo: '',
    expiryDate: '',
    qtyPurchased: '',
    unit: '',
    freeQty: '',
    freeUnit: '',
    mrp: '',
    discountPercent: '',
    gstPercent: '12',
    purchasePricePerUnit: '',
    amount: '',
    sellingPricePerUnit: ''
  })

  // UX & Flow state for Stock In
  const [isHeaderCollapsed, setIsHeaderCollapsed] = useState(false)
  const [editingIndex, setEditingIndex] = useState<number | null>(null)
  const [recentlyAddedIndex, setRecentlyAddedIndex] = useState<number | null>(null)
  const [lastUsedGstPercent, setLastUsedGstPercent] = useState('12')
  const [showScanInvoiceModal, setShowScanInvoiceModal] = useState(false)
  const medicineInputRef = useRef<HTMLInputElement>(null)

  const safeBatches = Array.isArray(batches) ? batches : []
  const searchableBatches = safeBatches.map((b: any) => ({
    ...b,
    medicine_name: b.medicine ? `${b.medicine.name}${b.medicine.strength ? ` (${b.medicine.strength})` : ''}` : ''
  }))
  const safePurchases = Array.isArray(purchases) ? purchases : []
  const searchablePurchases = safePurchases.map((p: any) => ({
    ...p,
    vendor_name: p.vendor?.name || '',
    batch_items_search: (p.batches || []).map((b: any) => b.medicine ? `${b.medicine.name}${b.medicine.strength ? ` (${b.medicine.strength})` : ''}` : '').join(' ')
  }))
  const safeMedicines = Array.isArray(medicines) ? medicines : []
  const safeVendors = Array.isArray(vendors) ? vendors : []

  useEffect(() => {
    loadAllData()
  }, [])

  // Auto focus medicine input when stock-in tab opens
  useEffect(() => {
    if (localTab === 'stock-in') {
      setTimeout(() => {
        medicineInputRef.current?.focus()
      }, 100)
    }
  }, [localTab])

  const handleQtyPurchasedChange = (val: string) => {
    const qty = parseFloat(val) || 0
    const pPrice = parseFloat(stockInItem.purchasePricePerUnit) || 0
    let newAmount = stockInItem.amount
    if (qty > 0 && pPrice > 0) {
      newAmount = (qty * pPrice).toFixed(2)
    }
    setStockInItem((prev) => ({
      ...prev,
      qtyPurchased: val,
      amount: newAmount
    }))
  }

  const handlePurchasePriceChange = (val: string) => {
    const pPrice = parseFloat(val) || 0
    const qty = parseFloat(stockInItem.qtyPurchased) || 0
    let newAmount = stockInItem.amount
    if (qty > 0 && pPrice > 0) {
      newAmount = (qty * pPrice).toFixed(2)
    }
    setStockInItem((prev) => ({
      ...prev,
      purchasePricePerUnit: val,
      amount: newAmount
    }))
  }

  const handleAmountChange = (val: string) => {
    const amt = parseFloat(val) || 0
    const qty = parseFloat(stockInItem.qtyPurchased) || 0
    let newPPrice = stockInItem.purchasePricePerUnit
    if (qty > 0 && amt >= 0) {
      newPPrice = (amt / qty).toFixed(2)
    }
    setStockInItem((prev) => ({
      ...prev,
      amount: val,
      purchasePricePerUnit: newPPrice
    }))
  }

  // Handle Medicine Selection with Auto-Filling Defaults
  const handleMedicineSelect = (selectedMed: Medicine | null) => {
    if (!selectedMed) {
      setStockInItem((prev) => ({
        ...prev,
        medicineId: '',
        unit: '',
        freeUnit: '',
        gstPercent: lastUsedGstPercent
      }))
      return
    }

    // Lookup previous batch pricing history for this medicine
    const prevBatch = safeBatches.find((b) => b.medicine_id === selectedMed.id)
    const defaultUnit = selectedMed.purchase_unit || selectedMed.inner_unit || selectedMed.base_unit || selectedMed.unit_label || 'Piece'

    setStockInItem((prev) => ({
      ...prev,
      medicineId: selectedMed.id,
      unit: defaultUnit,
      freeUnit: defaultUnit,
      gstPercent: selectedMed.default_gst_percent !== null && selectedMed.default_gst_percent !== undefined
        ? selectedMed.default_gst_percent.toString()
        : lastUsedGstPercent,
      mrp: prevBatch?.mrp ? prevBatch.mrp.toString() : prev.mrp,
      purchasePricePerUnit: prevBatch?.purchase_price_per_unit ? prevBatch.purchase_price_per_unit.toString() : prev.purchasePricePerUnit,
      sellingPricePerUnit: prevBatch?.selling_price_per_unit ? prevBatch.selling_price_per_unit.toString() : prev.sellingPricePerUnit
    }))
  }

  // MEDICINES CRUD SUBMISSION HANDLER
  const handleMedModalSave = async (formData: any) => {
    const norm = (str?: string | null) => {
      if (!str) return ''
      const s = str.trim().replace(/\s+/g, ' ')
      if (s.toUpperCase() === 'NULL' || s.toUpperCase() === 'UNDEFINED') return ''
      return s.toUpperCase()
    }
    const cleanName = norm(formData.name)
    const cleanStrength = norm(formData.strength)
    const cleanType = norm(formData.type) || 'TABLET'
    const cleanPack = norm(formData.pack)
    const cleanManufacturer = norm(formData.manufacturer)

    if (!cleanName) return showToast('Medicine Name is required', 'error')

    // 5-Tuple Duplicate check against existing medicines
    const isDuplicate = safeMedicines.some(
      (m) =>
        m.id !== editingMed?.id &&
        norm(m.name) === cleanName &&
        norm(m.strength) === cleanStrength &&
        (norm(m.type) || 'TABLET') === cleanType &&
        norm(m.pack) === cleanPack &&
        norm(m.manufacturer) === cleanManufacturer
    )
    if (isDuplicate) {
      showToast(`Medicine with this combination already exists! Duplicate entry is not allowed.`, 'error')
      return
    }

    try {
      const parsedGst = parseFloat(formData.defaultGstPercent)
      const gstPercent = isNaN(parsedGst) ? 12.0 : parsedGst
      const data = {
        name: cleanName,
        strength: cleanStrength || null,
        generic_name: formData.genericName ? formData.genericName.trim() : null,
        genericName: formData.genericName ? formData.genericName.trim() : null,
        manufacturer: cleanManufacturer || null,
        pack: cleanPack || null,
        type: cleanType || 'TABLET',
        unit_label: formData.unitLabel,
        unitLabel: formData.unitLabel,
        base_unit: formData.baseUnit || 'Piece',
        inner_unit: formData.innerUnit || null,
        units_per_inner: parseFloat(formData.unitsPerInner) || 1.0,
        purchase_unit: formData.purchaseUnit || null,
        inner_units_per_purchase: parseFloat(formData.innerUnitsPerPurchase) || 1.0,
        hsn_code: formData.hsnCode || null,
        hsnCode: formData.hsnCode || null,
        rack_no: formData.rackNo || null,
        rackNo: formData.rackNo || null,
        reorder_level: parseInt(formData.reorderLevel) || 0,
        reorderLevel: parseInt(formData.reorderLevel) || 0,
        default_gst_percent: gstPercent,
        defaultGstPercent: gstPercent
      }
      if (editingMed) {
        await updateMedicine({ id: editingMed.id, data, userId: currentUser?.id || '' })
        showToast('Medicine updated successfully', 'success')
      } else {
        await createMedicine({ data, userId: currentUser?.id || '' })
        showToast('Medicine created successfully', 'success')
      }
      setShowMedModal(false)
      setEditingMed(null)
    } catch (err: any) {
      showToast(err.message || 'Error saving medicine', 'error')
      throw err // Keeps modal open on error
    }
  }

  const startEditMed = (m: Medicine) => {
    setEditingMed(m)
    setShowMedModal(true)
  }

  const handleDeleteMed = async (id: string) => {
    if (!confirm('Are you sure you want to delete this medicine?')) return
    try {
      await deleteMedicine({ id, userId: currentUser?.id || '' })
      showToast('Medicine deleted', 'info')
    } catch (e: any) {
      showToast(e.message || 'Failed to delete medicine', 'error')
    }
  }

  // VENDORS CRUD SUBMISSION HANDLER
  const handleVendorModalSave = async (formData: any) => {
    const cleanName = (formData.name || '').trim().replace(/\s+/g, ' ').toUpperCase()
    if (!cleanName) return showToast('Vendor Name is required', 'error')

    // Duplicate check against existing vendors
    const isDuplicate = safeVendors.some(
      (v) => v.id !== editingVendor?.id && v.name.trim().replace(/\s+/g, ' ').toUpperCase() === cleanName
    )
    if (isDuplicate) {
      showToast(`Vendor "${cleanName}" already exists! Duplicate entry is not allowed.`, 'error')
      throw new Error(`Duplicate vendor name "${cleanName}"`)
    }

    const payload = {
      ...formData,
      name: cleanName
    }

    try {
      if (editingVendor) {
        await updateVendor({ id: editingVendor.id, data: payload, userId: currentUser?.id || '' })
        showToast('Vendor updated successfully', 'success')
      } else {
        await createVendor({ data: payload, userId: currentUser?.id || '' })
        showToast('Vendor created successfully', 'success')
      }
      setShowVendorModal(false)
      setEditingVendor(null)
    } catch (err: any) {
      showToast(err.message || 'Error saving vendor', 'error')
      throw err // Keeps modal open on error
    }
  }

  const startEditVendor = (v: Vendor) => {
    setEditingVendor(v)
    setShowVendorModal(true)
  }

  const handleDeleteVendor = async (id: string) => {
    if (!confirm('Are you sure you want to delete this vendor?')) return
    try {
      await deleteVendor({ id, userId: currentUser?.id || '' })
      showToast('Vendor deleted', 'info')
    } catch (e: any) {
      showToast(e.message || 'Failed to delete vendor', 'error')
    }
  }

  // STOCK ADJUSTMENT (Admin only)
  const handleAdjustSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedBatch) return
    const qty = parseInt(adjustQty)
    if (isNaN(qty) || qty === 0) return showToast('Please enter a non-zero adjustment amount', 'error')

    try {
      await adjustStock({
        id: selectedBatch.id,
        qtyChange: qty,
        reason: adjustReason,
        userId: currentUser?.id || ''
      })
      showToast('Stock adjusted successfully!', 'success')
      setShowAdjustModal(false)
      setSelectedBatch(null)
      setAdjustQty('')
    } catch (err: any) {
      showToast(err.message || 'Failed to adjust stock', 'error')
    }
  }

  // STOCK IN LOGIC
  const addStockInItem = () => {
    if (!stockInItem.medicineId) return showToast('Please select a medicine', 'error')
    if (!stockInItem.expiryDate) return showToast('Please select expiry date', 'error')

    const isoExpiryDate = formatExpiryToISO(stockInItem.expiryDate)
    if (!isoExpiryDate) return showToast('Invalid expiry date format', 'error')

    const expiryTimestamp = new Date(isoExpiryDate).getTime()
    const todayTimestamp = new Date().setHours(0, 0, 0, 0)
    if (expiryTimestamp <= todayTimestamp) {
      showToast('Warning: Expiry date should be a future date', 'info')
    }

    const qty = parseInt(stockInItem.qtyPurchased)
    const freeQty = parseInt(stockInItem.freeQty) || 0
    const mrp = parseFloat(stockInItem.mrp) || 0
    const discountPercent = parseFloat(stockInItem.discountPercent) || 0
    let pPrice = parseFloat(stockInItem.purchasePricePerUnit)
    const lineAmt = parseFloat(stockInItem.amount)
    const sPrice = parseFloat(stockInItem.sellingPricePerUnit)

    if (isNaN(pPrice) && !isNaN(lineAmt) && qty > 0) {
      pPrice = lineAmt / qty
    }

    if (isNaN(qty) || qty <= 0) return showToast('Purchased Quantity must be > 0', 'error')
    if (isNaN(pPrice) || pPrice < 0) return showToast('Purchase price invalid', 'error')
    if (isNaN(sPrice) || sPrice < pPrice) return showToast('Selling price should be >= purchase price', 'error')

    const selMed = safeMedicines.find(m => m.id === stockInItem.medicineId)
    const parsedItemGst = parseFloat(stockInItem.gstPercent)
    const gstPercent = !isNaN(parsedItemGst)
      ? parsedItemGst
      : (selMed?.default_gst_percent ?? 12.0)

    // Tax calculation per item
    const baseGross = qty * pPrice
    const discountAmt = baseGross * (discountPercent / 100)
    const taxableAmount = Math.max(0, baseGross - discountAmt)
    const gstAmount = taxableAmount * (gstPercent / 100)

    let cgstAmount = 0
    let sgstAmount = 0
    let igstAmount = 0

    if (purchaseForm.taxType === 'INTERSTATE') {
      igstAmount = gstAmount
    } else {
      cgstAmount = gstAmount / 2
      sgstAmount = gstAmount / 2
    }

    const selectedUnit = stockInItem.unit || selMed?.purchase_unit || selMed?.inner_unit || selMed?.base_unit || selMed?.unit_label || 'Piece'
    const selectedFreeUnit = stockInItem.freeUnit || selectedUnit

    const newItem = {
      medicineId: stockInItem.medicineId,
      batchNo: stockInItem.batchNo.trim() || 'N/A',
      expiryDate: isoExpiryDate,
      qty: qty,
      qtyPurchased: qty,
      unit: selectedUnit,
      freeQty,
      freeUnit: selectedFreeUnit,
      mrp,
      unitMrp: mrp,
      discountPercent,
      taxableAmount,
      cgstAmount,
      sgstAmount,
      igstAmount,
      gstPercent,
      purchasePrice: pPrice,
      purchasePricePerUnit: pPrice,
      unitPurchasePrice: pPrice,
      sellingPrice: sPrice,
      sellingPricePerUnit: sPrice,
      unitSellingPrice: sPrice
    }

    let updatedItems = [...purchaseForm.items]
    if (editingIndex !== null) {
      updatedItems[editingIndex] = newItem
      setRecentlyAddedIndex(editingIndex)
      showToast('Item batch updated', 'success')
    } else {
      updatedItems.push(newItem)
      setRecentlyAddedIndex(updatedItems.length - 1)
      showToast('Item batch added to invoice', 'success')
    }

    setPurchaseForm({
      ...purchaseForm,
      items: updatedItems
    })

    // Save GST% as default for next items
    setLastUsedGstPercent(stockInItem.gstPercent)

    // Reset stock item inputs & keep focus on Medicine
    setStockInItem({
      medicineId: '',
      batchNo: '',
      expiryDate: '',
      qtyPurchased: '',
      unit: '',
      freeQty: '',
      freeUnit: '',
      mrp: '',
      discountPercent: '',
      gstPercent: stockInItem.gstPercent,
      purchasePricePerUnit: '',
      amount: '',
      sellingPricePerUnit: ''
    })

    setEditingIndex(null)

    // Highlight row briefly
    setTimeout(() => {
      setRecentlyAddedIndex(null)
    }, 2000)

    // Auto focus medicine input
    setTimeout(() => {
      medicineInputRef.current?.focus()
    }, 50)

    // Auto-collapse header if header is complete and user started adding items
    if (purchaseForm.vendorId && purchaseForm.purchaseInvoiceNo.trim()) {
      setIsHeaderCollapsed(true)
    }
  }

  const editStockInItem = (index: number) => {
    const item: any = purchaseForm.items[index]
    if (!item) return

    const lineAmount = (item.qtyPurchased * item.purchasePricePerUnit).toFixed(2)

    setStockInItem({
      medicineId: item.medicineId,
      batchNo: item.batchNo === 'N/A' ? '' : item.batchNo,
      expiryDate: item.expiryDate ? item.expiryDate.slice(0, 7) : '',
      qtyPurchased: (item.qtyPurchased || item.qty || '').toString(),
      unit: item.unit || '',
      freeQty: item.freeQty ? item.freeQty.toString() : '',
      freeUnit: item.freeUnit || '',
      mrp: (item.unitMrp ?? item.mrp ?? 0).toString(),
      discountPercent: item.discountPercent ? item.discountPercent.toString() : '',
      gstPercent: item.gstPercent ? item.gstPercent.toString() : '12',
      purchasePricePerUnit: (item.unitPurchasePrice ?? item.purchasePricePerUnit).toString(),
      amount: lineAmount,
      sellingPricePerUnit: (item.unitSellingPrice ?? item.sellingPricePerUnit).toString()
    })
    setEditingIndex(index)
    medicineInputRef.current?.focus()
  }

  const cancelEditStockInItem = () => {
    setEditingIndex(null)
    setStockInItem({
      medicineId: '',
      batchNo: '',
      expiryDate: '',
      qtyPurchased: '',
      unit: '',
      freeQty: '',
      freeUnit: '',
      mrp: '',
      discountPercent: '',
      gstPercent: lastUsedGstPercent,
      purchasePricePerUnit: '',
      amount: '',
      sellingPricePerUnit: ''
    })
    medicineInputRef.current?.focus()
  }

  const removeStockInItem = (idx: number) => {
    const items = [...purchaseForm.items]
    items.splice(idx, 1)
    setPurchaseForm({ ...purchaseForm, items })
    if (editingIndex === idx) {
      cancelEditStockInItem()
    }
    showToast('Item removed from invoice', 'info')
  }

  const handlePurchaseSubmit = async () => {
    if (!purchaseForm.vendorId) return showToast('Please select a vendor', 'error')
    if (!purchaseForm.purchaseInvoiceNo.trim()) return showToast('Please enter purchase invoice number', 'error')
    if (purchaseForm.items.length === 0) return showToast('Add at least one item batch to the invoice', 'error')

    const taxableAmount = purchaseForm.items.reduce((sum, item) => sum + (item.taxableAmount || 0), 0)
    const cgstAmount = purchaseForm.items.reduce((sum, item) => sum + (item.cgstAmount || 0), 0)
    const sgstAmount = purchaseForm.items.reduce((sum, item) => sum + (item.sgstAmount || 0), 0)
    const igstAmount = purchaseForm.items.reduce((sum, item) => sum + (item.igstAmount || 0), 0)
    const gstAmount = cgstAmount + sgstAmount + igstAmount
    const totalAmount = (taxableAmount + gstAmount) > 0
      ? (taxableAmount + gstAmount)
      : purchaseForm.items.reduce((sum, item) => sum + (item.qtyPurchased * item.purchasePricePerUnit), 0)

    const isCash = purchaseForm.purchaseType === 'CASH'
    const paidAmount = isCash ? totalAmount : (parseFloat(purchaseForm.paidAmount) || 0)
    const pendingAmount = Math.max(0, totalAmount - paidAmount)

    let status = 'PAID'
    if (!isCash) {
      if (paidAmount >= totalAmount) status = 'PAID'
      else if (paidAmount > 0) status = 'PARTIAL'
      else status = 'PENDING'
    }

    try {
      await createPurchase({
        data: {
          vendorId: purchaseForm.vendorId,
          purchaseInvoiceNo: purchaseForm.purchaseInvoiceNo,
          purchaseDate: purchaseForm.purchaseDate,
          purchaseType: purchaseForm.purchaseType,
          dueDate: purchaseForm.dueDate || null,
          paymentDate: purchaseForm.paymentDate || null,
          paymentStatus: status,
          paymentMode: purchaseForm.paymentMode,
          taxableAmount,
          cgstAmount,
          sgstAmount,
          igstAmount,
          gstAmount,
          gstPercent: purchaseForm.items.length > 0 ? (purchaseForm.items[0].gstPercent ?? 12) : 12,
          totalAmount,
          paidAmount,
          pendingAmount,
          notes: purchaseForm.notes,
          items: purchaseForm.items
        },
        userId: currentUser?.id || ''
      })

      showToast('Stock purchase logged successfully!', 'success')
      setPurchaseForm({
        vendorId: '',
        purchaseInvoiceNo: '',
        purchaseDate: new Date().toISOString().split('T')[0],
        purchaseType: 'CASH',
        taxType: 'INTRASTATE',
        dueDate: '',
        paymentDate: new Date().toISOString().split('T')[0],
        paidAmount: '',
        paymentStatus: 'PAID',
        paymentMode: 'CASH',
        notes: '',
        items: []
      })
      setIsHeaderCollapsed(false)
      setEditingIndex(null)
      setLocalTab('batches')
    } catch (e: any) {
      showToast(e.message || 'Error logging purchase', 'error')
    }
  }

  // Filter lists based on search
  const filteredBatches = safeBatches.filter(b =>
    (b.medicine?.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (b.batch_no || '').toLowerCase().includes(searchQuery.toLowerCase())
  )

  const filteredMedicines = safeMedicines.filter(m =>
    (m.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (m.generic_name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (m.manufacturer || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (m.pack || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (m.type || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (m.rack_no || '').toLowerCase().includes(searchQuery.toLowerCase())
  )

  const filteredVendors = safeVendors.filter(v =>
    (v.name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (v.phone || '').includes(searchQuery) ||
    (v.gstin || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (v.drug_license_no || '').toLowerCase().includes(searchQuery.toLowerCase())
  )

  const getDaysToExpiry = (expiryStr: string) => {
    const diff = new Date(expiryStr).getTime() - new Date().getTime()
    return Math.ceil(diff / (1000 * 60 * 60 * 24))
  }

  const formatExpiryToISO = (expiryInput: string): string => {
    if (!expiryInput || !expiryInput.trim()) return ''
    const str = expiryInput.trim()

    // Format: YYYY-MM (e.g. from <input type="month"> like "2028-08")
    if (/^\d{4}-\d{2}$/.test(str)) {
      const [y, m] = str.split('-').map(Number)
      const lastDay = new Date(y, m, 0).getDate()
      const mm = String(m).padStart(2, '0')
      const dd = String(lastDay).padStart(2, '0')
      return `${y}-${mm}-${dd}`
    }

    // Format: YYYY-MM-DD (already full date)
    if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
      return str
    }

    // Format: MM/YY or MM/YYYY or MM-YY or MM-YYYY
    if (/^\d{1,2}[\/\-]\d{2,4}$/.test(str)) {
      const parts = str.split(/[\/\-]/)
      const m = parseInt(parts[0], 10)
      let yStr = parts[1]
      if (yStr.length === 2) yStr = '20' + yStr
      const y = parseInt(yStr, 10)
      if (m >= 1 && m <= 12 && y > 2000 && y < 2100) {
        const lastDay = new Date(y, m, 0).getDate()
        const mm = String(m).padStart(2, '0')
        const dd = String(lastDay).padStart(2, '0')
        return `${y}-${mm}-${dd}`
      }
    }

    // Format: 4 digits MMYY (e.g. 0828)
    if (/^\d{4}$/.test(str)) {
      const m = parseInt(str.substring(0, 2), 10)
      const y = parseInt('20' + str.substring(2, 4), 10)
      if (m >= 1 && m <= 12 && y > 2000 && y < 2100) {
        const lastDay = new Date(y, m, 0).getDate()
        const mm = String(m).padStart(2, '0')
        const dd = String(lastDay).padStart(2, '0')
        return `${y}-${mm}-${dd}`
      }
    }

    const parsed = new Date(str)
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().split('T')[0]
    }

    return str
  }

  const formatExpiryDisplay = (dateStr: string): string => {
    if (!dateStr) return '---'
    const d = new Date(dateStr)
    if (isNaN(d.getTime())) return dateStr
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const year = d.getFullYear()
    return `${month}/${year}`
  }

  const selectedVendorObject = safeVendors.find(v => v.id === purchaseForm.vendorId)
  const isHeaderValid = Boolean(purchaseForm.vendorId && purchaseForm.purchaseInvoiceNo.trim() && purchaseForm.purchaseDate)

  return (
    <div className="space-y-6 animate-fade-in pb-12">


      {/* Sub Tabs Navigation */}
      <div className="flex border-b border-slate-200 overflow-x-auto">
        {[
          { id: 'stock-in', label: 'Stock Purchase In', badge: purchaseForm.items.length ? `${purchaseForm.items.length} items` : null },
          { id: 'batches', label: 'Current Stock' },
          { id: 'medicines', label: 'Medicines List' },
          { id: 'purchases', label: 'Purchase History' },
          { id: 'vendors', label: 'Vendors List' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => {
              setLocalTab(tab.id)
              setSearchQuery('')
            }}
            className={`px-6 py-3 font-semibold text-sm border-b-2 transition-all cursor-pointer whitespace-nowrap flex items-center gap-2 ${localTab === tab.id
              ? 'border-cyan-500 text-cyan-600 bg-cyan-50/40'
              : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
              }`}
          >
            <span>{tab.label}</span>
            {tab.badge && (
              <span className="text-[10px] font-bold px-2 py-0.5 bg-cyan-600 text-white rounded-full">
                {tab.badge}
              </span>
            )}
          </button>
        ))}
      </div>



      {/* --- CURRENT STOCK BATCHES TAB --- */}
      {localTab === 'batches' && (
        <DataTable
          columns={[
            { key: 'medicine', header: 'Medicine', sortable: true, sortValue: (b: any) => b.medicine?.name || '', render: (b: any) => <span className="font-bold text-slate-900">{b.medicine?.name}</span> },
            { key: 'batch_no', header: 'Batch No.', sortable: true, render: (b: any) => <span className="font-mono text-xs text-slate-600">{b.batch_no}</span> },
            { key: 'expiry_date', header: 'Expiry Date', sortable: true, render: (b: any) => <span className="font-mono text-xs">{formatExpiryDisplay(b.expiry_date)}</span> },
            {
              key: 'qty_available',
              header: 'Available Stock',
              sortable: true,
              sortValue: (b: any) => b.qty_available,
              render: (b: any) => {
                const breakdownInfo = b.medicine ? formatStockBreakdown(b.medicine, b.qty_available) : null
                return (
                  <div className="flex flex-col">
                    <span className="font-bold text-slate-900 font-sans text-xs">
                      {breakdownInfo ? breakdownInfo.breakdown : `${b.qty_available} ${b.medicine?.unit_label || 'Pcs'}`}
                    </span>
                    <span className="font-mono text-[11px] text-slate-500">
                      Total: {b.qty_available} {b.medicine?.base_unit || b.medicine?.unit_label || 'Piece'}s
                    </span>
                  </div>
                )
              }
            },
            { key: 'purchase_price_per_unit', header: 'Purchase Price', sortable: true, align: 'right', render: (b: any) => <span className="font-mono">₹{b.purchase_price_per_unit.toFixed(2)}</span> },
            { key: 'selling_price_per_unit', header: 'Selling Price', sortable: true, align: 'right', render: (b: any) => <span className="font-mono font-bold text-slate-900">₹{b.selling_price_per_unit.toFixed(2)}</span> },
            {
              key: 'status',
              header: 'Status',
              sortable: true,
              align: 'center',
              render: (b: any) => {
                const daysToExpiry = getDaysToExpiry(b.expiry_date)
                const isExpired = daysToExpiry <= 0
                const isNearExpiry = daysToExpiry > 0 && daysToExpiry <= 30
                return isExpired ? (
                  <span className="inline-flex px-2.5 py-0.5 text-xs rounded-full font-bold bg-red-100 text-red-700">Expired</span>
                ) : isNearExpiry ? (
                  <span className="inline-flex px-2.5 py-0.5 text-xs rounded-full font-bold bg-amber-100 text-amber-800">Expiring in {daysToExpiry}d</span>
                ) : (
                  <span className="inline-flex px-2.5 py-0.5 text-xs rounded-full font-bold bg-cyan-100 text-cyan-800">Active</span>
                )
              }
            },
            { key: 'created_at', header: 'Created At', optional: true, sortable: true, sortValue: (b: any) => b.created_at ? new Date(b.created_at).getTime() : 0, render: (b: any) => <span className="font-mono text-xs text-slate-600">{formatDateTime(b.created_at)}</span> },
            { key: 'updated_at', header: 'Updated At', optional: true, sortable: true, sortValue: (b: any) => b.updated_at ? new Date(b.updated_at).getTime() : 0, render: (b: any) => <span className="font-mono text-xs text-slate-600">{formatDateTime(b.updated_at)}</span> },
            {
              key: 'actions',
              header: 'Actions',
              align: 'center',
              render: (b: any) => currentUser?.role === 'ADMIN' ? (
                <button
                  onClick={() => {
                    setSelectedBatch(b)
                    setAdjustQty('')
                    setAdjustReason('Count correction')
                    setShowAdjustModal(true)
                  }}
                  className="text-xs text-cyan-600 hover:text-cyan-700 font-bold underline cursor-pointer"
                >
                  Adjust Stock
                </button>
              ) : null
            }
          ]}
          data={searchableBatches}
          loading={loading}
          rowKey={(b) => b.id}
          searchPlaceholder="Search by medicine or batch no..."
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchFilterKeys={['medicine_name', 'batch_no']}
          emptyMessage="No stock batches found"
          emptySubtext="Perform a Stock Purchase In to add medicine batches."
        />
      )}

      {/* --- MEDICINES LIST TAB --- */}
      {localTab === 'medicines' && (
        <DataTable
          columns={[
            { key: 'name', header: 'Medicine Name', sortable: true, render: (m: any) => <span className="font-bold text-slate-900">{m.name}</span> },
            { key: 'strength', header: 'Strength', sortable: true, render: (m: any) => <span className="font-semibold text-cyan-800 bg-cyan-50 border border-cyan-200/60 px-2 py-0.5 rounded text-xs">{m.strength || 'N/A'}</span> },
            { key: 'generic_name', header: 'Generic Name', sortable: true, render: (m: any) => <span className="text-xs text-slate-600 font-medium">{m.generic_name || 'N/A'}</span> },
            { key: 'manufacturer', header: 'Manufacturer', sortable: true, render: (m: any) => <span className="text-xs text-slate-600">{m.manufacturer || 'N/A'}</span> },
            { key: 'pack', header: 'Pack', sortable: true, render: (m: any) => <span className="font-mono text-xs">{m.pack || 'N/A'}</span> },
            { key: 'type', header: 'Type', sortable: true, render: (m: any) => <span className="font-mono text-xs">{m.type}</span> },
            { key: 'unit_label', header: 'Unit Label', sortable: true, render: (m: any) => <span className="capitalize">{m.unit_label}</span> },
            { key: 'hsn_code', header: 'HSN Code', sortable: true, render: (m: any) => <span className="font-mono text-xs">{m.hsn_code || 'N/A'}</span> },
            {
              key: 'rack_no', header: 'Rack No', sortable: true, render: (m: any) => (
                m.rack_no
                  ? <span className="font-mono text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200 px-1.5 py-0.5 rounded">{m.rack_no}</span>
                  : <span className="text-xs text-slate-400">N/A</span>
              )
            },
            { key: 'reorder_level', header: 'Reorder Level', sortable: true, align: 'right', render: (m: any) => <span className="font-mono font-bold text-slate-800">{m.reorder_level}</span> },
            { key: 'default_gst_percent', header: 'GST %', sortable: true, align: 'right', render: (m: any) => <span className="font-mono">{m.default_gst_percent}%</span> },
            { key: 'created_at', header: 'Created At', optional: true, sortable: true, sortValue: (m: any) => m.created_at ? new Date(m.created_at).getTime() : 0, render: (m: any) => <span className="font-mono text-xs text-slate-600">{formatDateTime(m.created_at)}</span> },
            { key: 'updated_at', header: 'Updated At', optional: true, sortable: true, sortValue: (m: any) => m.updated_at ? new Date(m.updated_at).getTime() : 0, render: (m: any) => <span className="font-mono text-xs text-slate-600">{formatDateTime(m.updated_at)}</span> },
            {
              key: 'actions',
              header: 'Actions',
              align: 'center',
              render: (m: any) => (
                <div className="flex items-center justify-center space-x-2">
                  <button
                    onClick={() => startEditMed(m)}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer inline-flex items-center"
                  >
                    <Edit2 className="h-3 w-3 mr-1" /> Edit
                  </button>
                  {currentUser?.role === 'ADMIN' && (
                    <button
                      onClick={() => handleDeleteMed(m.id)}
                      className="text-xs text-red-600 hover:text-red-800 font-bold cursor-pointer inline-flex items-center"
                    >
                      <Trash2 className="h-3 w-3 mr-1" /> Delete
                    </button>
                  )}
                </div>
              )
            }
          ]}
          data={safeMedicines}
          loading={loading}
          rowKey={(m) => m.id}
          searchPlaceholder="Search medicines by name, generic, pack..."
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          emptyMessage="No medicines registered"
          emptySubtext="Add your first medicine to manage pharmacy inventory."
          emptyActionLabel="Add Medicine"
          onEmptyAction={() => {
            setEditingMed(null)
            setShowMedModal(true)
          }}
          toolbarActions={
            <button
              onClick={() => {
                setEditingMed(null)
                setShowMedModal(true)
              }}
              className="flex items-center justify-center px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
            >
              <Plus className="h-4 w-4 mr-1.5" /> Add Medicine
            </button>
          }
        />
      )}

      {/* --- STOCK PURCHASE IN TAB (REDESIGNED V2) --- */}
      {localTab === 'stock-in' && (
        <div className="space-y-6">

          {/* ZONE 1: INVOICE HEADER CARD (COLLAPSIBLE / PINNED STRIP) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm transition-all duration-200">
            {isHeaderCollapsed ? (
              /* COLLAPSED SINGLE-LINE SUMMARY STRIP */
              <div className="p-4 bg-slate-900 text-white rounded-2xl flex flex-wrap items-center justify-between gap-4 shadow-md border border-slate-800">
                <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span className="text-slate-400">Vendor:</span>
                    <strong className="text-white text-sm">{selectedVendorObject?.name || 'Not Selected'}</strong>
                  </div>

                  <div className="flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span className="text-slate-400">Invoice:</span>
                    <strong className="font-mono text-cyan-300 text-sm">#{purchaseForm.purchaseInvoiceNo || '---'}</strong>
                  </div>

                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-cyan-400 shrink-0" />
                    <span className="text-slate-400">Date:</span>
                    <span className="font-mono">{new Date(purchaseForm.purchaseDate).toLocaleDateString('en-GB')}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${purchaseForm.purchaseType === 'CREDIT' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      }`}>
                      {purchaseForm.purchaseType}
                    </span>
                    <span className="text-slate-400 font-mono text-[11px]">
                      {purchaseForm.taxType === 'INTERSTATE' ? 'IGST (Interstate)' : 'CGST+SGST (In-State)'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setIsHeaderCollapsed(false)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-lg text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
                >
                  <Edit2 className="w-3.5 h-3.5" /> Edit Header
                </button>
              </div>
            ) : (
              /* EXPANDED FULL HEADER CARD */
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <h3 className="text-md font-bold text-slate-900 flex items-center gap-2">
                    <FilePlus className="h-5 w-5 text-cyan-500" /> Purchase Invoice Header
                  </h3>

                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setShowScanInvoiceModal(true)}
                      className="text-xs font-bold text-violet-600 hover:text-violet-800 flex items-center gap-1 cursor-pointer bg-violet-50 px-2.5 py-1 rounded-lg border border-violet-200/60"
                    >
                      <ScanLine className="w-3.5 h-3.5" /> Scan Invoice
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setEditingVendor(null)
                        setShowVendorModal(true)
                      }}
                      className="text-xs font-bold text-cyan-600 hover:text-cyan-800 flex items-center gap-1 cursor-pointer bg-cyan-50 px-2.5 py-1 rounded-lg border border-cyan-200/60"
                    >
                      <Plus className="w-3.5 h-3.5" /> Quick Add Vendor
                    </button>

                    {isHeaderValid && (
                      <button
                        type="button"
                        onClick={() => setIsHeaderCollapsed(true)}
                        className="text-xs font-semibold text-slate-600 hover:text-slate-800 flex items-center gap-1 cursor-pointer bg-slate-100 px-3 py-1 rounded-lg border border-slate-200"
                      >
                        <ChevronUp className="w-4 h-4" /> Collapse
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {/* Vendor Combobox */}
                  <div className="md:col-span-1">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                      Vendor <span className="text-red-500">*</span>
                    </label>
                    <VendorTypeahead
                      vendors={safeVendors}
                      value={purchaseForm.vendorId}
                      onChange={(vendorId) => setPurchaseForm({ ...purchaseForm, vendorId })}
                      error={!purchaseForm.vendorId ? 'Vendor is required' : undefined}
                    />
                  </div>

                  {/* Invoice Number */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                      Invoice Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. PUR-1001"
                      value={purchaseForm.purchaseInvoiceNo}
                      onChange={(e) => setPurchaseForm({ ...purchaseForm, purchaseInvoiceNo: e.target.value })}
                      className={`w-full py-2 px-3 rounded-lg border text-sm focus:outline-none focus:ring-2 font-mono ${!purchaseForm.purchaseInvoiceNo.trim()
                        ? 'border-slate-200 focus:ring-cyan-500'
                        : 'border-cyan-500 bg-cyan-50/10 font-bold focus:ring-cyan-500'
                        }`}
                    />
                  </div>

                  {/* Purchase Date */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                      Purchase Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={purchaseForm.purchaseDate}
                      onChange={(e) => setPurchaseForm({ ...purchaseForm, purchaseDate: e.target.value })}
                      className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-medium"
                    />
                  </div>

                  {/* Purchase Type */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Purchase Type</label>
                    <select
                      value={purchaseForm.purchaseType}
                      onChange={(e) => {
                        const pType = e.target.value
                        setPurchaseForm({
                          ...purchaseForm,
                          purchaseType: pType,
                          paymentStatus: pType === 'CREDIT' ? 'PENDING' : 'PAID'
                        })
                      }}
                      className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-bold text-slate-800 bg-slate-50/50"
                    >
                      <option value="CASH">CASH</option>
                      <option value="CREDIT">CREDIT</option>
                    </select>
                  </div>

                  {/* Tax Type */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Tax Type</label>
                    <select
                      value={purchaseForm.taxType}
                      onChange={(e) => setPurchaseForm({ ...purchaseForm, taxType: e.target.value })}
                      className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-semibold text-slate-800"
                    >
                      <option value="INTRASTATE">CGST + SGST (In-State)</option>
                      <option value="INTERSTATE">IGST (Out of State)</option>
                    </select>
                  </div>

                  {/* Payment Mode */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Payment Mode</label>
                    <select
                      value={purchaseForm.paymentMode}
                      onChange={(e) => setPurchaseForm({ ...purchaseForm, paymentMode: e.target.value })}
                      className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    >
                      <option value="CASH">CASH</option>
                      <option value="UPI">UPI</option>
                      <option value="BANK">BANK TRANSFER</option>
                      <option value="CARD">CARD</option>
                    </select>
                  </div>

                  {/* Remarks / Notes */}
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Remarks / Notes</label>
                    <input
                      type="text"
                      placeholder="Optional notes or reference..."
                      value={purchaseForm.notes}
                      onChange={(e) => setPurchaseForm({ ...purchaseForm, notes: e.target.value })}
                      className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                    />
                  </div>
                </div>

                {/* CREDIT BREAKDOWN PANEL */}
                {purchaseForm.purchaseType === 'CREDIT' && (
                  <div className="p-4 bg-amber-50/70 border border-amber-200/80 rounded-xl space-y-3 mt-3 animate-fade-in">
                    <div className="flex items-center gap-2 text-amber-900 font-bold text-xs uppercase tracking-wide">
                      <CreditCard className="w-4 h-4 text-amber-600" /> Credit Invoice Payment Details
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-amber-800 uppercase mb-1">Paid Amount (₹)</label>
                        <input
                          type="number"
                          step="0.01"
                          placeholder="₹ 0.00"
                          value={purchaseForm.paidAmount}
                          onChange={(e) => setPurchaseForm({ ...purchaseForm, paidAmount: e.target.value })}
                          className="w-full py-2 px-3 rounded-lg border border-amber-300 bg-white text-sm font-bold text-amber-900 focus:outline-none focus:ring-2 focus:ring-amber-500 font-mono"
                        />
                      </div>

                      {/* Computed Pending Amount Field with AUTO badge */}
                      <div>
                        <label className="block text-xs font-bold text-amber-800 uppercase mb-1 flex items-center justify-between">
                          <span>Pending Amount</span>
                          <span className="text-[10px] font-extrabold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded flex items-center gap-1">
                            <Lock className="w-3 h-3" /> AUTO
                          </span>
                        </label>
                        <input
                          type="text"
                          readOnly
                          value={`₹ ${(() => {
                            const tot = purchaseForm.items.reduce((sum, item) => sum + (item.qtyPurchased * item.purchasePricePerUnit), 0)
                            const pd = parseFloat(purchaseForm.paidAmount) || 0
                            return Math.max(0, tot - pd).toFixed(2)
                          })()}`}
                          className="w-full py-2 px-3 rounded-lg border border-amber-200/80 bg-amber-100/50 text-sm font-bold text-red-700 font-mono cursor-default focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-amber-800 uppercase mb-1">Due Date</label>
                        <input
                          type="date"
                          value={purchaseForm.dueDate}
                          onChange={(e) => setPurchaseForm({ ...purchaseForm, dueDate: e.target.value })}
                          className="w-full py-2 px-3 rounded-lg border border-amber-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-amber-800 uppercase mb-1">Payment Date</label>
                        <input
                          type="date"
                          value={purchaseForm.paymentDate}
                          onChange={(e) => setPurchaseForm({ ...purchaseForm, paymentDate: e.target.value })}
                          className="w-full py-2 px-3 rounded-lg border border-amber-300 bg-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* ZONE 2: STICKY COMPACT "ADD ITEM BATCH" ENTRY PANEL */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sticky top-2 z-20 transition-all">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-cyan-600" />
                <h4 className="text-sm font-bold text-slate-900">
                  {editingIndex !== null ? (
                    <span className="text-indigo-600 flex items-center gap-1.5">
                      <Edit2 className="w-4 h-4" /> Edit Batch Item #{editingIndex + 1}
                    </span>
                  ) : (
                    'Add Medicine Batch Item'
                  )}
                </h4>
              </div>

              <div className="text-xs text-slate-400 font-medium flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditingMed(null)
                    setShowMedModal(true)
                  }}
                  className="text-xs font-bold text-cyan-600 hover:text-cyan-800 underline cursor-pointer mr-2 flex items-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" /> Quick Create Medicine
                </button>
                <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">Press Enter to Add</span>
                {editingIndex !== null && (
                  <button
                    onClick={cancelEditStockInItem}
                    className="text-xs text-slate-500 hover:text-slate-800 underline font-semibold cursor-pointer"
                  >
                    Cancel Editing
                  </button>
                )}
              </div>
            </div>

            {/* FAST DATA ENTRY ROW / GRID */}
            <div
              onKeyDown={(e) => {
                if (e.key === 'Enter' || (e.ctrlKey && e.key === 'Enter')) {
                  e.preventDefault()
                  addStockInItem()
                }
              }}
              className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-12 gap-3 items-end"
            >
              {/* Medicine Typeahead */}
              <div className="lg:col-span-3">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                  Medicine <span className="text-red-500">*</span>
                </label>
                <MedicineTypeahead
                  medicines={safeMedicines}
                  value={stockInItem.medicineId}
                  onChange={handleMedicineSelect}
                  inputRef={medicineInputRef}
                />
              </div>

              {/* Batch No */}
              <div className="lg:col-span-2">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                  Batch No.
                </label>
                <input
                  type="text"
                  placeholder="e.g. B-9021 (Optional)"
                  value={stockInItem.batchNo}
                  onChange={(e) => setStockInItem({ ...stockInItem, batchNo: e.target.value })}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono font-semibold"
                />
              </div>

              {/* Expiry Date (Month & Year) */}
              <div className="lg:col-span-2">
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-bold text-slate-500 uppercase">
                    Expiry (MM/YY) <span className="text-red-500">*</span>
                  </label>
                  <span className="text-[10px] text-slate-400 font-medium">Month & Year</span>
                </div>
                <input
                  type="month"
                  value={stockInItem.expiryDate ? stockInItem.expiryDate.slice(0, 7) : ''}
                  onChange={(e) => setStockInItem({ ...stockInItem, expiryDate: e.target.value })}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono font-semibold"
                />

              </div>

              {/* Qty Purchased */}
              <div className="lg:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                  Qty <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  placeholder="10"
                  value={stockInItem.qtyPurchased}
                  onChange={(e) => handleQtyPurchasedChange(e.target.value)}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono font-bold text-slate-900"
                />
              </div>

              {/* Unit Dropdown */}
              <div className="lg:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                  Unit <span className="text-red-500">*</span>
                </label>
                <select
                  value={stockInItem.unit}
                  onChange={(e) => setStockInItem({ ...stockInItem, unit: e.target.value, freeUnit: stockInItem.freeUnit || e.target.value })}
                  className="w-full py-2 px-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-bold text-slate-800 bg-white"
                >
                  {getAvailableUnitsForMedicine(safeMedicines.find(m => m.id === stockInItem.medicineId)).map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>

              {/* Free Qty */}
              <div className="lg:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Free</label>
                <input
                  type="number"
                  placeholder="0"
                  value={stockInItem.freeQty}
                  onChange={(e) => setStockInItem({ ...stockInItem, freeQty: e.target.value })}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono text-cyan-700"
                />
              </div>

              {/* Free Unit Dropdown */}
              <div className="lg:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Free Unit</label>
                <select
                  value={stockInItem.freeUnit || stockInItem.unit}
                  onChange={(e) => setStockInItem({ ...stockInItem, freeUnit: e.target.value })}
                  className="w-full py-2 px-2 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-medium text-slate-700 bg-white"
                >
                  {getAvailableUnitsForMedicine(safeMedicines.find(m => m.id === stockInItem.medicineId)).map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>

              {/* MRP */}
              <div className="lg:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">MRP (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="150"
                  value={stockInItem.mrp}
                  onChange={(e) => setStockInItem({ ...stockInItem, mrp: e.target.value })}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono"
                />
              </div>

              {/* Disc % */}
              <div className="lg:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Disc %</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="0"
                  value={stockInItem.discountPercent}
                  onChange={(e) => setStockInItem({ ...stockInItem, discountPercent: e.target.value })}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono"
                />
              </div>

              {/* Purchase Price */}
              <div className="lg:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1 flex items-center justify-between">
                  <span>Pur.Price</span>
                  {stockInItem.unit && <span className="text-[10px] text-cyan-600 font-normal lowercase">/{stockInItem.unit}</span>}
                </label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="₹/unit"
                  value={stockInItem.purchasePricePerUnit}
                  onChange={(e) => handlePurchasePriceChange(e.target.value)}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono font-medium"
                />
              </div>

              {/* COMPUTED READ-ONLY AMOUNT FIELD */}
              <div className="lg:col-span-2">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1 flex items-center justify-between">
                  <span>Net Amount</span>
                  <span className="text-[10px] font-extrabold text-cyan-700 bg-cyan-100/90 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                    <Lock className="w-2.5 h-2.5" /> AUTO
                  </span>
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Qty × Price"
                    value={stockInItem.amount}
                    onChange={(e) => handleAmountChange(e.target.value)}
                    className="w-full py-2 px-3 rounded-lg border border-cyan-200 bg-cyan-50/70 text-sm font-extrabold text-cyan-950 font-mono focus:outline-none focus:ring-0"
                  />
                </div>
              </div>

              {/* GST % */}
              <div className="lg:col-span-1">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">GST %</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="12"
                  value={stockInItem.gstPercent}
                  onChange={(e) => setStockInItem({ ...stockInItem, gstPercent: e.target.value })}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono font-semibold"
                />
              </div>

              {/* Selling Price */}
              <div className="lg:col-span-2">
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1 flex items-center justify-between">
                  <span>Sell Price</span>
                  {stockInItem.unit && <span className="text-[10px] text-cyan-600 font-normal lowercase">/{stockInItem.unit}</span>}
                </label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="₹/unit"
                  value={stockInItem.sellingPricePerUnit}
                  onChange={(e) => setStockInItem({ ...stockInItem, sellingPricePerUnit: e.target.value })}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono font-semibold text-slate-900"
                />
              </div>

              {/* ADD / UPDATE BUTTON */}
              <div className="lg:col-span-2">
                <button
                  type="button"
                  onClick={addStockInItem}
                  className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer ${editingIndex !== null
                    ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-indigo-500/20'
                    : 'bg-cyan-600 hover:bg-cyan-700 text-white shadow-cyan-500/20'
                    }`}
                >
                  {editingIndex !== null ? (
                    <>
                      <Check className="w-4 h-4" /> Update Batch
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" /> Add Batch Item
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* LIVE EQUIVALENT STOCK ADDITION PREVIEW */}
            {Boolean(stockInItem.medicineId && parseFloat(stockInItem.qtyPurchased) > 0) && (() => {
              const selMed = safeMedicines.find(m => m.id === stockInItem.medicineId)
              if (!selMed) return null
              const basePurchased = convertToBaseQuantity(selMed, parseFloat(stockInItem.qtyPurchased) || 0, stockInItem.unit)
              const baseFree = convertToBaseQuantity(selMed, parseFloat(stockInItem.freeQty) || 0, stockInItem.freeUnit || stockInItem.unit)
              const totalBase = basePurchased + baseFree
              const baseUnitLabel = selMed.base_unit || selMed.unit_label || 'Piece'
              const factor = (stockInItem.unit ? (selMed.purchase_unit && stockInItem.unit.toLowerCase() === selMed.purchase_unit.toLowerCase() ? (selMed.inner_units_per_purchase || 1) * (selMed.units_per_inner || 1) : (selMed.inner_unit && stockInItem.unit.toLowerCase() === selMed.inner_unit.toLowerCase() ? (selMed.units_per_inner || 1) : 1)) : 1)

              return (
                <div className="mt-3.5 p-3 bg-cyan-50/90 border border-cyan-200 rounded-xl text-xs flex items-center justify-between text-cyan-950 font-medium animate-fade-in shadow-xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-cyan-600 shrink-0" />
                    <span>
                      Equivalent Quantity: <strong className="font-mono text-sm text-cyan-900 font-extrabold">{basePurchased} {baseUnitLabel}s</strong>
                      {baseFree > 0 && (
                        <span className="text-cyan-800 ml-1.5 font-mono">
                          (+ {baseFree} {baseUnitLabel}s Free = <strong>{totalBase} Total {baseUnitLabel}s</strong>)
                        </span>
                      )}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-600 bg-white px-2.5 py-1 rounded-lg border border-cyan-200/80 shadow-xs">
                    1 {stockInItem.unit || 'Unit'} = {factor} {baseUnitLabel}s
                  </div>
                </div>
              )
            })()}
          </div>

          {/* ZONE 3: RESPONSIVE BATCH ITEMS TABLE (WITH STICKY MEDICINE COLUMN) */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-6">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-md font-bold text-slate-900 flex items-center gap-2">
                <Layers className="h-5 w-5 text-cyan-500" /> Batch Items in Invoice
                <span className="ml-2 text-xs font-mono font-normal bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
                  {purchaseForm.items.length} items
                </span>
              </h3>
            </div>

            <div className="overflow-x-auto relative rounded-xl border border-slate-200">
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                    {/* Sticky Medicine Header Column */}
                    <th className="px-4 py-3 sticky left-0 bg-slate-50 z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)] min-w-[200px]">
                      Medicine Name
                    </th>
                    <th className="px-4 py-3">HSN / GST</th>
                    <th className="px-4 py-3">Batch No</th>
                    <th className="px-4 py-3">Expiry Date</th>
                    <th className="px-4 py-3 text-right">Qty</th>
                    <th className="px-4 py-3 text-right">Free</th>
                    <th className="px-4 py-3 text-right">MRP</th>
                    <th className="px-4 py-3 text-right">Disc %</th>
                    <th className="px-4 py-3 text-right">Pur. Price</th>
                    <th className="px-4 py-3 text-right">Sell Price</th>
                    {/* Read-Only Net Total Column */}
                    <th className="px-4 py-3 text-right min-w-[110px]">Net Total</th>
                    <th className="px-4 py-3 text-right min-w-[120px]">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {purchaseForm.items.map((item: any, index) => {
                    const med = safeMedicines.find((m) => m.id === item.medicineId)
                    // Net Total = (Qty x Rate - Discount) + GST, matching the invoice-level totals below
                    const itemTotal = (item.taxableAmount || 0) + (item.cgstAmount || 0) + (item.sgstAmount || 0) + (item.igstAmount || 0)
                    const isRecentlyAdded = recentlyAddedIndex === index
                    const isBeingEdited = editingIndex === index

                    return (
                      <tr
                        key={index}
                        className={`transition-colors duration-500 ${isRecentlyAdded
                          ? 'bg-cyan-50/90 font-medium'
                          : isBeingEdited
                            ? 'bg-indigo-50/80 border-l-4 border-l-indigo-600'
                            : 'hover:bg-slate-50/70'
                          }`}
                      >
                        {/* Sticky Medicine Body Column */}
                        <td className="px-4 py-3 font-semibold text-slate-900 sticky left-0 bg-white z-10 shadow-[2px_0_5px_-2px_rgba(0,0,0,0.05)]">
                          <div>{med?.name || 'Medicine'}</div>
                          {med?.pack && <div className="text-[11px] text-slate-500 font-mono font-normal">Pack: {med.pack}</div>}
                        </td>
                        <td className="px-4 py-3 text-xs font-mono">
                          <div>{med?.hsn_code || '---'}</div>
                          <span className="text-[10px] bg-cyan-50 text-cyan-700 border border-cyan-200/60 font-sans px-1.5 py-0.5 rounded font-bold">
                            GST {item.gstPercent ?? med?.default_gst_percent ?? 12}%
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono text-xs font-semibold">{item.batchNo}</td>
                        <td className="px-4 py-3 text-xs font-mono">
                          {formatExpiryDisplay(item.expiryDate)}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                          {item.qtyPurchased} <span className="text-[11px] font-sans font-normal text-slate-500">{item.unit || 'Unit'}</span>
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-cyan-700 font-semibold">
                          {item.freeQty > 0 ? `+${item.freeQty} ${item.freeUnit || item.unit || ''}` : '-'}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-xs text-slate-600">
                          {item.mrp > 0 ? `₹${item.mrp.toFixed(2)}` : '-'}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-xs text-slate-600">
                          {item.discountPercent > 0 ? `${item.discountPercent}%` : '-'}
                        </td>
                        <td className="px-4 py-3 text-right font-mono">₹{item.purchasePricePerUnit.toFixed(2)}</td>
                        <td className="px-4 py-3 text-right font-mono font-semibold text-slate-900">₹{item.sellingPricePerUnit.toFixed(2)}</td>

                        {/* COMPUTED READ-ONLY NET TOTAL */}
                        <td className="px-4 py-3 text-right font-mono font-extrabold text-cyan-900 bg-cyan-50/40">
                          ₹{itemTotal.toFixed(2)}
                        </td>

                        {/* INLINE ROW ACTIONS */}
                        <td className="px-4 py-3 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => editStockInItem(index)}
                              className="px-2 py-1 text-xs text-indigo-600 hover:bg-indigo-50 rounded font-semibold transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <Edit2 className="w-3.5 h-3.5" /> Edit
                            </button>
                            <button
                              type="button"
                              onClick={() => removeStockInItem(index)}
                              className="px-2 py-1 text-xs text-red-600 hover:bg-red-50 rounded font-semibold transition-colors cursor-pointer flex items-center gap-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" /> Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}

                  {/* FRIENDLY EMPTY STATE */}
                  {purchaseForm.items.length === 0 && (
                    <tr>
                      <td colSpan={12} className="px-6 py-12 text-center bg-slate-50/40">
                        <div className="max-w-md mx-auto space-y-3">
                          <div className="w-12 h-12 rounded-full bg-cyan-50 text-cyan-600 flex items-center justify-center mx-auto border border-cyan-100">
                            <Package className="w-6 h-6" />
                          </div>
                          <p className="text-sm font-semibold text-slate-800">No items added to this purchase invoice yet.</p>
                          <p className="text-xs text-slate-500">
                            Select a medicine in the entry bar above or press <kbd className="px-1.5 py-0.5 bg-white border rounded text-[11px] font-mono shadow-xs">Enter</kbd> after filling details to add your first batch item.
                          </p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* ZONE 4: PINNED RUNNING TOTALS & FINAL SUBMIT BAR */}
          {(() => {
            const taxable = purchaseForm.items.reduce((s, i) => s + (i.taxableAmount || 0), 0)
            const cgst = purchaseForm.items.reduce((s, i) => s + (i.cgstAmount || 0), 0)
            const sgst = purchaseForm.items.reduce((s, i) => s + (i.sgstAmount || 0), 0)
            const igst = purchaseForm.items.reduce((s, i) => s + (i.igstAmount || 0), 0)
            const totalGst = cgst + sgst + igst
            const grandTotal = taxable + totalGst > 0
              ? (taxable + totalGst)
              : purchaseForm.items.reduce((sum, item) => sum + (item.qtyPurchased * item.purchasePricePerUnit), 0)

            const canSubmit = isHeaderValid && purchaseForm.items.length > 0

            return (
              <div className="sticky bottom-4 z-30 bg-slate-900 text-white p-5 rounded-2xl shadow-2xl border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
                {/* COMPUTED TAX BREAKDOWN STRIP */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 w-full md:w-auto">
                  <div className="bg-slate-800/80 px-3.5 py-2 rounded-xl border border-slate-700/60">
                    <span className="text-[11px] text-slate-400 font-semibold block flex items-center gap-1">
                      Taxable Amount <Lock className="w-2.5 h-2.5 text-cyan-400" />
                    </span>
                    <span className="font-bold text-white font-mono text-base">₹{taxable.toFixed(2)}</span>
                  </div>

                  {purchaseForm.taxType === 'INTERSTATE' ? (
                    <div className="bg-slate-800/80 px-3.5 py-2 rounded-xl border border-slate-700/60">
                      <span className="text-[11px] text-slate-400 font-semibold block flex items-center gap-1">
                        IGST Total <Lock className="w-2.5 h-2.5 text-cyan-400" />
                      </span>
                      <span className="font-bold text-white font-mono text-base">₹{igst.toFixed(2)}</span>
                    </div>
                  ) : (
                    <>
                      <div className="bg-slate-800/80 px-3.5 py-2 rounded-xl border border-slate-700/60">
                        <span className="text-[11px] text-slate-400 font-semibold block flex items-center gap-1">
                          CGST Total <Lock className="w-2.5 h-2.5 text-cyan-400" />
                        </span>
                        <span className="font-bold text-white font-mono text-base">₹{cgst.toFixed(2)}</span>
                      </div>
                      <div className="bg-slate-800/80 px-3.5 py-2 rounded-xl border border-slate-700/60">
                        <span className="text-[11px] text-slate-400 font-semibold block flex items-center gap-1">
                          SGST Total <Lock className="w-2.5 h-2.5 text-cyan-400" />
                        </span>
                        <span className="font-bold text-white font-mono text-base">₹{sgst.toFixed(2)}</span>
                      </div>
                    </>
                  )}

                  <div className="bg-slate-800/80 px-3.5 py-2 rounded-xl border border-slate-700/60">
                    <span className="text-[11px] text-cyan-400 font-semibold block flex items-center gap-1">
                      Total GST <Lock className="w-2.5 h-2.5 text-cyan-400" />
                    </span>
                    <span className="font-bold text-cyan-300 font-mono text-base">₹{totalGst.toFixed(2)}</span>
                  </div>
                </div>

                {/* GRAND TOTAL & SUBMIT BUTTON */}
                <div className="flex items-center justify-between md:justify-end gap-6 w-full md:w-auto border-t md:border-t-0 border-slate-800 pt-3 md:pt-0">
                  <div>
                    <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Grand Total Amount</p>
                    <p className="text-2xl font-black text-cyan-400 font-mono">₹{grandTotal.toFixed(2)}</p>
                  </div>

                  <div className="relative group">
                    <button
                      type="button"
                      onClick={handlePurchaseSubmit}
                      disabled={!canSubmit}
                      className="px-6 py-3 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl text-sm shadow-lg shadow-cyan-500/20 transition-all disabled:bg-slate-800 disabled:text-slate-500 disabled:shadow-none cursor-pointer flex items-center gap-2"
                    >
                      <span>Log Stock Purchase</span>
                      <ArrowRight className="h-4 w-4" />
                    </button>

                    {/* TOOLTIP ON HOVER WHEN DISABLED */}
                    {!canSubmit && (
                      <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-60 p-2.5 bg-slate-950 text-slate-300 text-xs rounded-lg border border-slate-800 shadow-xl z-50">
                        <p className="font-semibold text-amber-400 mb-1">Cannot submit yet:</p>
                        <ul className="list-disc pl-4 space-y-0.5 text-[11px]">
                          {!purchaseForm.vendorId && <li>Select a vendor</li>}
                          {!purchaseForm.purchaseInvoiceNo.trim() && <li>Enter invoice number</li>}
                          {purchaseForm.items.length === 0 && <li>Add at least 1 item batch</li>}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )
          })()}
        </div>
      )}

      {/* --- PURCHASE HISTORY TAB --- */}
      {localTab === 'purchases' && (
        <DataTable
          columns={[
            { key: 'purchase_date', header: 'Date', sortable: true, render: (p: any) => <span className="font-mono text-xs text-slate-600">{new Date(p.purchase_date).toLocaleDateString('en-GB')}</span> },
            {
              key: 'vendor',
              header: 'Vendor & Invoice',
              sortable: true,
              sortValue: (p: any) => p.vendor?.name || '',
              render: (p: any) => (
                <div>
                  <p className="font-bold text-slate-900">{p.vendor?.name}</p>
                  <p className="text-xs font-mono text-slate-400">Inv #{p.purchase_invoice_no}</p>
                </div>
              )
            },
            {
              key: 'purchase_type',
              header: 'Type',
              sortable: true,
              render: (p: any) => (
                <span className={`text-[10px] px-2 py-0.5 rounded font-extrabold uppercase ${p.purchase_type === 'CREDIT' ? 'bg-amber-100 text-amber-800' : 'bg-cyan-100 text-cyan-800'
                  }`}>
                  {p.purchase_type || 'CASH'}
                </span>
              )
            },
            { key: 'total_amount', header: 'Total Amount', sortable: true, align: 'right', render: (p: any) => <span className="font-mono font-bold text-slate-900">₹{p.total_amount.toFixed(2)}</span> },
            {
              key: 'paid_amount',
              header: 'Paid Amount',
              sortable: true,
              align: 'right',
              render: (p: any) => {
                const paid = p.paid_amount !== undefined ? p.paid_amount : (p.purchase_type === 'CREDIT' ? 0 : p.total_amount)
                return <span className="font-mono font-semibold text-cyan-700">₹{paid.toFixed(2)}</span>
              }
            },
            {
              key: 'pending_amount',
              header: 'Pending Dues',
              sortable: true,
              align: 'right',
              render: (p: any) => {
                const pending = p.pending_amount !== undefined ? p.pending_amount : (p.purchase_type === 'CREDIT' ? p.total_amount : 0)
                return <span className={`font-mono font-semibold ${pending > 0 ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>₹{pending.toFixed(2)}</span>
              }
            },
            { key: 'due_date', header: 'Due Date', sortable: true, render: (p: any) => <span className="font-mono text-xs">{p.due_date ? new Date(p.due_date).toLocaleDateString('en-GB') : '-'}</span> },
            {
              key: 'payment_status',
              header: 'Status',
              sortable: true,
              align: 'center',
              render: (p: any) => (
                <span className={`text-[10px] px-2 py-0.5 rounded font-extrabold uppercase ${p.payment_status === 'PENDING' ? 'bg-red-100 text-red-800' :
                  p.payment_status === 'PARTIAL' ? 'bg-amber-100 text-amber-800' : 'bg-cyan-100 text-cyan-800'
                  }`}>
                  {p.payment_status || 'PAID'}
                </span>
              )
            },
            { key: 'payment_mode', header: 'Mode', sortable: true, render: (p: any) => <span className="font-mono text-xs uppercase">{p.payment_mode || 'CASH'}</span> },
            {
              key: 'items_summary',
              header: 'Batch Items',
              render: (p: any) => {
                const batchCount = p.batches?.length || 0
                if (!batchCount) return <span className="text-xs text-slate-400">N/A</span>
                const firstItem = p.batches[0]?.medicine?.name || 'Item'
                return (
                  <span className="inline-flex items-center gap-1.5 text-xs text-slate-600">
                    <span className="truncate max-w-[140px]">{firstItem}</span>
                    {batchCount > 1 && (
                      <span className="shrink-0 px-1.5 py-0.5 rounded-full bg-cyan-100 text-cyan-700 font-bold text-[10px]">
                        +{batchCount - 1} more
                      </span>
                    )}
                  </span>
                )
              }
            },
            { key: 'notes', header: 'Notes', render: (p: any) => <span className="text-xs text-slate-400 truncate max-w-xs block">{p.notes || 'N/A'}</span> },
            { key: 'created_at', header: 'Created At', optional: true, sortable: true, sortValue: (p: any) => p.created_at ? new Date(p.created_at).getTime() : 0, render: (p: any) => <span className="font-mono text-xs text-slate-600">{formatDateTime(p.created_at)}</span> },
            { key: 'updated_at', header: 'Updated At', optional: true, sortable: true, sortValue: (p: any) => p.updated_at ? new Date(p.updated_at).getTime() : 0, render: (p: any) => <span className="font-mono text-xs text-slate-600">{formatDateTime(p.updated_at)}</span> }
          ]}
          data={searchablePurchases}
          loading={loading}
          rowKey={(p) => p.id}
          onRowClick={(p) => setSelectedPurchase(p)}
          searchPlaceholder="Search purchase history by invoice, vendor, notes..."
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          searchFilterKeys={['purchase_invoice_no', 'vendor_name', 'notes', 'batch_items_search']}
          emptyMessage="No purchases recorded"
          emptySubtext="Log your first stock purchase in the Stock Purchase In tab."
        />
      )}

      {/* --- VENDORS LIST TAB --- */}
      {localTab === 'vendors' && (
        <DataTable
          columns={[
            { key: 'name', header: 'Vendor Name', sortable: true, render: (v: any) => <span className="font-bold text-slate-900">{v.name}</span> },
            { key: 'phone', header: 'Phone Number', sortable: true, render: (v: any) => <span className="font-mono text-xs">{v.phone}</span> },
            { key: 'address', header: 'Address', sortable: true, render: (v: any) => <span className="text-xs text-slate-600">{v.address}</span> },
            { key: 'gstin', header: 'GSTIN', sortable: true, render: (v: any) => <span className="font-mono text-xs uppercase">{v.gstin || 'N/A'}</span> },
            { key: 'drug_license_no', header: 'Drug License No', sortable: true, render: (v: any) => <span className="font-mono text-xs uppercase">{v.drug_license_no || 'N/A'}</span> },
            { key: 'notes', header: 'Notes', render: (v: any) => <span className="text-xs text-slate-400 truncate max-w-xs block">{v.notes || 'N/A'}</span> },
            { key: 'created_at', header: 'Created At', optional: true, sortable: true, sortValue: (v: any) => v.created_at ? new Date(v.created_at).getTime() : 0, render: (v: any) => <span className="font-mono text-xs text-slate-600">{formatDateTime(v.created_at)}</span> },
            { key: 'updated_at', header: 'Updated At', optional: true, sortable: true, sortValue: (v: any) => v.updated_at ? new Date(v.updated_at).getTime() : 0, render: (v: any) => <span className="font-mono text-xs text-slate-600">{formatDateTime(v.updated_at)}</span> },
            {
              key: 'actions',
              header: 'Actions',
              align: 'center',
              render: (v: any) => (
                <div className="flex items-center justify-center space-x-2">
                  <button
                    onClick={() => startEditVendor(v)}
                    className="text-xs text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer inline-flex items-center"
                  >
                    <Edit2 className="h-3 w-3 mr-1" /> Edit
                  </button>
                  {currentUser?.role === 'ADMIN' && (
                    <button
                      onClick={() => handleDeleteVendor(v.id)}
                      className="text-xs text-red-600 hover:text-red-800 font-bold cursor-pointer inline-flex items-center"
                    >
                      <Trash2 className="h-3 w-3 mr-1" /> Delete
                    </button>
                  )}
                </div>
              )
            }
          ]}
          data={safeVendors}
          loading={loading}
          rowKey={(v) => v.id}
          searchPlaceholder="Search vendors by name, phone, gstin..."
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          emptyMessage="No vendors registered"
          emptySubtext="Add your first supplier vendor to begin logging purchases."
          emptyActionLabel="Add Vendor"
          onEmptyAction={() => {
            setEditingVendor(null)
            setShowVendorModal(true)
          }}
          toolbarActions={
            <button
              onClick={() => {
                setEditingVendor(null)
                setShowVendorModal(true)
              }}
              className="flex items-center justify-center px-4 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
            >
              <Plus className="h-4 w-4 mr-1.5" /> Add Vendor
            </button>
          }
        />
      )}

      {/* --- REDESIGNED MEDICINE ADD/EDIT MODAL --- */}
      <RedesignedMedicineModal
        isOpen={showMedModal}
        onClose={() => {
          setShowMedModal(false)
          setEditingMed(null)
        }}
        onSubmit={handleMedModalSave}
        editingMed={editingMed}
        existingMedicines={safeMedicines}
      />

      {/* --- REDESIGNED VENDOR ADD/EDIT MODAL --- */}
      <RedesignedVendorModal
        isOpen={showVendorModal}
        onClose={() => {
          setShowVendorModal(false)
          setEditingVendor(null)
        }}
        onSubmit={handleVendorModalSave}
        editingVendor={editingVendor}
        existingVendors={safeVendors}
      />

      {/* --- STOCK ADJUSTMENT MODAL --- */}
      {showAdjustModal && selectedBatch && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 border border-slate-100">
            <h3 className="text-lg font-bold text-slate-900 mb-2">Adjust Inventory Stock</h3>
            <p className="text-xs text-slate-500 mb-4">
              Medicine: <span className="font-semibold text-slate-800">{selectedBatch.medicine?.name}</span> (Batch: <span className="font-mono">{selectedBatch.batch_no}</span>)
            </p>

            <form onSubmit={handleAdjustSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Current Stock Qty</label>
                <input
                  type="text"
                  disabled
                  value={selectedBatch.qty_available}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm bg-slate-50 text-slate-400 font-semibold font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Adjustment Qty *</label>
                <input
                  type="number"
                  placeholder="e.g. -5 to decrease, 10 to increase"
                  value={adjustQty}
                  onChange={(e) => setAdjustQty(e.target.value)}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 font-semibold font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Reason for Adjustment *</label>
                <select
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full py-2 px-3 rounded-lg border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500"
                >
                  <option value="Count correction">Count correction</option>
                  <option value="Damage">Damage</option>
                  <option value="Expiry write-off">Expiry write-off</option>
                  <option value="Theft or Loss">Theft or Loss</option>
                </select>
              </div>

              <div className="flex justify-end space-x-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setShowAdjustModal(false)
                    setSelectedBatch(null)
                  }}
                  className="px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-650 hover:bg-slate-50 font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-cyan-500 text-white rounded-lg text-sm font-semibold hover:bg-cyan-600 shadow-md shadow-cyan-500/10 cursor-pointer"
                >
                  Apply Stock Correction
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- PURCHASE INVOICE DETAILS MODAL --- */}
      {selectedPurchase && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl max-w-4xl w-full max-h-[90vh] flex flex-col border border-slate-100">
            {/* Header */}
            <div className="flex items-start justify-between px-6 py-5 border-b border-slate-100">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-cyan-500" /> Purchase Invoice Details
                </h3>
                <p className="text-xs text-slate-500 mt-1 font-mono">
                  Inv #{selectedPurchase.purchase_invoice_no} &middot; {new Date(selectedPurchase.purchase_date).toLocaleDateString('en-GB')}
                </p>
              </div>
              <button
                onClick={() => setSelectedPurchase(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Summary Info */}
            <div className="px-6 py-4 border-b border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4 bg-slate-50/50">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1"><Building2 className="w-3 h-3" /> Vendor</p>
                <p className="text-sm font-bold text-slate-900 mt-0.5">{selectedPurchase.vendor?.name || 'N/A'}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1"><Tag className="w-3 h-3" /> Type</p>
                <span className={`inline-block mt-0.5 text-[10px] px-2 py-0.5 rounded font-extrabold uppercase ${selectedPurchase.purchase_type === 'CREDIT' ? 'bg-amber-100 text-amber-800' : 'bg-cyan-100 text-cyan-800'}`}>
                  {selectedPurchase.purchase_type || 'CASH'}
                </span>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1"><CreditCard className="w-3 h-3" /> Status</p>
                <span className={`inline-block mt-0.5 text-[10px] px-2 py-0.5 rounded font-extrabold uppercase ${selectedPurchase.payment_status === 'PENDING' ? 'bg-red-100 text-red-800' : selectedPurchase.payment_status === 'PARTIAL' ? 'bg-amber-100 text-amber-800' : 'bg-cyan-100 text-cyan-800'}`}>
                  {selectedPurchase.payment_status || 'PAID'}
                </span>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1"><Calendar className="w-3 h-3" /> Due Date</p>
                <p className="text-sm font-semibold text-slate-700 mt-0.5 font-mono">{selectedPurchase.due_date ? new Date(selectedPurchase.due_date).toLocaleDateString('en-GB') : '-'}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Total Amount</p>
                <p className="text-sm font-bold text-slate-900 mt-0.5 font-mono">₹{Number(selectedPurchase.total_amount || 0).toFixed(2)}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Paid Amount</p>
                <p className="text-sm font-bold text-cyan-700 mt-0.5 font-mono">
                  ₹{Number(selectedPurchase.paid_amount !== undefined ? selectedPurchase.paid_amount : (selectedPurchase.purchase_type === 'CREDIT' ? 0 : selectedPurchase.total_amount)).toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Pending Dues</p>
                <p className={`text-sm font-bold mt-0.5 font-mono ${(selectedPurchase.pending_amount ?? 0) > 0 ? 'text-rose-600' : 'text-slate-400'}`}>
                  ₹{Number(selectedPurchase.pending_amount !== undefined ? selectedPurchase.pending_amount : (selectedPurchase.purchase_type === 'CREDIT' ? selectedPurchase.total_amount : 0)).toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Payment Mode</p>
                <p className="text-sm font-semibold text-slate-700 mt-0.5 uppercase">{selectedPurchase.payment_mode || 'CASH'}</p>
              </div>
            </div>

            {/* Items Table */}
            <div className="flex-1 overflow-auto px-6 py-4">
              <p className="text-xs font-bold text-slate-500 uppercase mb-2 flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-cyan-500" /> Batch Items ({selectedPurchase.batches?.length || 0})
              </p>
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left border-collapse min-w-max">
                  <thead>
                    <tr className="bg-[#0B132B] text-cyan-500 font-black uppercase text-[10px] tracking-wider">
                      <th className="px-3 py-2.5">Medicine</th>
                      <th className="px-3 py-2.5">Batch No</th>
                      <th className="px-3 py-2.5">Expiry</th>
                      <th className="px-3 py-2.5 text-right">Qty</th>
                      <th className="px-3 py-2.5 text-right">Free</th>
                      <th className="px-3 py-2.5 text-right">MRP</th>
                      <th className="px-3 py-2.5 text-right">Purchase/Unit</th>
                      <th className="px-3 py-2.5 text-right">Sell/Unit</th>
                      <th className="px-3 py-2.5 text-right">GST%</th>
                      <th className="px-3 py-2.5 text-right">Taxable Amt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-[#0B132B] text-xs">
                    {(selectedPurchase.batches || []).map((b: any) => (
                      <tr key={b.id} className="hover:bg-slate-50">
                        <td className="px-3 py-2.5 font-semibold flex items-center gap-1.5">
                          <Pill className="w-3.5 h-3.5 text-slate-400 shrink-0" /> {b.medicine?.name || 'N/A'}
                        </td>
                        <td className="px-3 py-2.5 font-mono">{b.batch_no || '-'}</td>
                        <td className="px-3 py-2.5 font-mono">{b.expiry_date ? new Date(b.expiry_date).toLocaleDateString('en-GB', { month: '2-digit', year: 'numeric' }) : '-'}</td>
                        <td className="px-3 py-2.5 text-right font-mono font-bold">{b.qty_purchased}</td>
                        <td className="px-3 py-2.5 text-right font-mono text-slate-500">{b.qty_free || 0}</td>
                        <td className="px-3 py-2.5 text-right font-mono">₹{Number(b.mrp || 0).toFixed(2)}</td>
                        <td className="px-3 py-2.5 text-right font-mono">₹{Number(b.purchase_price_per_unit || 0).toFixed(2)}</td>
                        <td className="px-3 py-2.5 text-right font-mono">₹{Number(b.selling_price_per_unit || 0).toFixed(2)}</td>
                        <td className="px-3 py-2.5 text-right font-mono">{b.gst_percent ?? 0}%</td>
                        <td className="px-3 py-2.5 text-right font-mono font-bold">₹{Number(b.taxable_amount || 0).toFixed(2)}</td>
                      </tr>
                    ))}
                    {(!selectedPurchase.batches || selectedPurchase.batches.length === 0) && (
                      <tr>
                        <td colSpan={10} className="px-3 py-6 text-center text-slate-400 text-xs">No batch items recorded for this purchase.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {selectedPurchase.notes && (
                <div className="mt-4 p-3 bg-slate-50 border border-slate-100 rounded-xl">
                  <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">Notes</p>
                  <p className="text-xs text-slate-600">{selectedPurchase.notes}</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setSelectedPurchase(null)}
                className="px-4 py-2 bg-[#0B132B] hover:bg-[#162244] text-cyan-500 font-bold rounded-xl text-xs transition cursor-pointer shadow-xs border border-cyan-500/40"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {showScanInvoiceModal && (
        <ScanPurchaseInvoice
          userId={currentUser?.id || ''}
          onClose={() => setShowScanInvoiceModal(false)}
          onCommitted={(purchase: Purchase) => {
            setShowScanInvoiceModal(false)
            loadAllData()
            showToast(`Purchase invoice #${purchase.purchase_invoice_no} saved from scan`, 'success')
          }}
        />
      )}
    </div>
  )
}
